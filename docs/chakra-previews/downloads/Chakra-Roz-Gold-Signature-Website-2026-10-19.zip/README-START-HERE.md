# Chakra Gold Signature — October 19, 2026 website ZIP

PREVIEW LINK
https://kiralabs.org/chakra-previews/roz-oct19-gold-signature-backgrounds/

The site is a self-contained static HTML/CSS/JavaScript export of that version:
- Gold Signature background on the opening page, Company, Information Gap and Consequences.
- Stronger animated entrance of "Becomes." while preserving the original Information reveal.
- The Ferris-wheel ecosystem page stays unchanged.
- Current wording, four technology cards, links, color adjustments, unique orbits, footer and privacy are preserved.
- All five supporter logos included under assets/supporters and referenced locally.

HOW ROZ CAN PUBLISH IT TO GITHUB
1. Download and unzip this archive.
2. Upload ALL extracted files/folders, not the .zip, to the root of her GitHub repository.
3. Enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /(root).
4. Keep CSS/JS, privacy/, and assets/ at their original relative paths.

BEFORE GOING PUBLIC
- Verify that hello@chakra.io and all supporter marks and wording are approved.
- Site includes a noindex/nofollow tag intended for preview; change once indexing is desired.
- Google Fonts still load externally and have fallback fonts.
- The product buttons open informational dialogs, not functioning products.

Source Kira commit: 00c2515d1c7a35fcdb372783273f1b7cdea6ec0f.
The previous downloaded ZIP and earlier previews remain unchanged.
