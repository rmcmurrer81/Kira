# CHAKRA INTELLIGENT SYSTEMS — WEBSITE TRANSFER PACKET

This ZIP contains the complete static website design that Roz liked:
https://kiralabs.org/chakra-previews/roz-oct18-shared-purpose-unique-orbits-small20/

Original Kira Labs source revision: 9645a3de5f157c0a78735fb224da1e891b5b1b06
Prepared: October 18, 2026

HOW TO DEPLOY TO ROZ'S GITHUB
1. Download and unzip this file.
2. The extracted contents include index.html, CSS and JavaScript files, assets/, and privacy/.
3. Upload the CONTENTS of this folder to the root of her own GitHub repository (index.html must be at root).
4. Under GitHub repository Settings → Pages, set "Deploy from a branch", "main", and "/(root)". Or upload under a docs/ folder and choose that folder.
5. Wait for GitHub Pages deployment and open the new URL.

INCLUDED
- All site HTML, CSS, JavaScript, animated six-node ecosystem, and four technology cards.
- Full-screen compact four-card section with unique ROSA/HCI/DI/RIT orbit shapes.
- The softened purple and gold effects and all accepted prior website changes.
- Privacy page and all five supporter-logo image files.
- No dependencies on kiralabs.org paths for images; logos use local assets/supporters/*.png.

BEFORE PUBLIC LAUNCH
- The Contact links point to hello@chakra.io; Roz should confirm this address.
- The draft uses <meta name="robots" content="noindex,nofollow">. Remove when launching publicly if search indexing is desired.
- Verify permission and accuracy for supporter logos, trademarks, titles, and claims.
- This package is a functional FRONT-END WEBSITE DESIGN, not working ROSA/HCI/DI/RIT products.
- Google Fonts are loaded from their public CDN, otherwise system fallbacks apply.

Keep the file/folder hierarchy unchanged when uploading. No parts of the
rest of the Kira Labs project/repository are needed.
