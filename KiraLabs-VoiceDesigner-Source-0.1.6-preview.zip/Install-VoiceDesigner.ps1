param([string]$InstallDir, [switch]$NonInteractive, [switch]$AllowCompatibilityWarnings, [switch]$NoLaunch, [switch]$NoShortcuts)
$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$local=[Environment]::GetFolderPath('LocalApplicationData')
$parent=[IO.Path]::GetFullPath((Join-Path $local 'KiraLabs'))
$profileParent=[IO.Path]::GetFullPath((Join-Path (Join-Path $env:USERPROFILE 'AppData\Local') 'KiraLabs'))
$allowedParents=@($parent,$profileParent)
if(!$InstallDir){$InstallDir=Join-Path $parent 'VoiceDesigner'}
$InstallDir=[IO.Path]::GetFullPath($InstallDir).TrimEnd('\')
if([IO.Path]::GetFileName($InstallDir)-notin @('VoiceDesigner','VoiceDesigner-Test')){throw 'Choose an absolute install folder whose final name is VoiceDesigner or VoiceDesigner-Test.'}
if(![Environment]::Is64BitOperatingSystem){throw 'This release requires 64-bit Windows.'}
if((Test-Path -LiteralPath $InstallDir)-and((Get-Item -LiteralPath $InstallDir -Force).Attributes-band[IO.FileAttributes]::ReparsePoint)){throw 'Refusing install through a linked application root.'}
$marker=Join-Path $InstallDir '.kiralabs-voice-designer.json'
if((Test-Path -LiteralPath $InstallDir)-and !(Test-Path -LiteralPath $marker)-and (Get-ChildItem -LiteralPath $InstallDir -Force|Select-Object -First 1)){throw 'Existing nonempty directory is not an owned Voice Designer installation.'}
if(Test-Path -LiteralPath $marker){try{$existing=Get-Content -LiteralPath $marker -Raw|ConvertFrom-Json;if($existing.product-ne'KiraLabs.VoiceDesigner'-or[IO.Path]::GetFullPath($existing.root).TrimEnd('\')-ine$InstallDir){throw 'Owned marker mismatch.'}}catch{throw 'The existing folder has an invalid owned-installation marker.'}}
$warnings=New-Object Collections.Generic.List[string]
$ramBytes=$null
try{$pc=Get-CimInstance Win32_ComputerSystem -ErrorAction Stop;$ramBytes=[double]$pc.TotalPhysicalMemory}catch{}
if(!$ramBytes){try{[void][Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic');$computer=New-Object Microsoft.VisualBasic.Devices.ComputerInfo;$ramBytes=[double]$computer.TotalPhysicalMemory}catch{}}
if($ramBytes){$usable=[math]::Round($ramBytes/1GB,1);Write-Host "Detected usable RAM: $usable GiB (reference PC: 32 GB class, 31.4 GiB usable).";if($ramBytes-lt31GB){$warnings.Add('Usable RAM is below the reference PC. This is an advisory comparison, not a validated minimum. You may continue.')}}else{$warnings.Add('RAM could not be detected. Compatibility remains unverified; you may continue.')}
$smi=$null
foreach($candidate in @(($env:SystemRoot+'\System32\nvidia-smi.exe'),($env:ProgramFiles+'\NVIDIA Corporation\NVSMI\nvidia-smi.exe'))){if([IO.File]::Exists($candidate)){$smi=$candidate;break}}
if(!$smi){foreach($folder in ([string]$env:PATH).Split(';')){if($folder){$candidate=Join-Path $folder 'nvidia-smi.exe';if([IO.File]::Exists($candidate)){$smi=$candidate;break}}}}
if($smi){
 $query=$null
 try{
  $info=New-Object Diagnostics.ProcessStartInfo;$info.FileName=$smi;$info.Arguments='--query-gpu=name,memory.total,driver_version --format=csv,noheader,nounits';$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $query=New-Object Diagnostics.Process;$query.StartInfo=$info;[void]$query.Start()
  if(!$query.WaitForExit(10000)){$query.Kill();throw 'NVIDIA hardware query timed out.'}
  $text=$query.StandardOutput.ReadToEnd();$detail=$query.StandardError.ReadToEnd();if($query.ExitCode-ne0){throw $detail}
  $rows=@($text.Trim()-split'\r?\n'|Where-Object{$_})
  if(!$rows.Count){throw 'No NVIDIA hardware information returned.'}
  foreach($row in $rows){$fields=$row.Split(',');if($fields.Count-lt3){throw 'Unrecognized NVIDIA hardware output.'};$name=$fields[0].Trim();$memory=$fields[1].Trim();$driver=$fields[2].Trim();Write-Host "Detected NVIDIA GPU: $name; total VRAM: $memory MiB; driver: $driver"
   [double]$vram=0;if([double]::TryParse($memory,[ref]$vram)-and$vram-lt15000){$warnings.Add('Reported GPU memory is below the 16 GB reference card. Other GPUs are not validated; generation may fail. You may continue.')}
   [version]$driverVersion=$null;if([version]::TryParse($driver,[ref]$driverVersion)){if($driverVersion.Major-lt580){$warnings.Add('NVIDIA driver branch is older than R580, the CUDA 13 baseline. Update through NVIDIA when convenient; this installer does not change drivers. You may continue.')}}else{$warnings.Add('Driver version could not be parsed; CUDA 13 compatibility is unknown.')}
  }
 }catch{$warnings.Add('NVIDIA GPU/driver detection was unavailable: '+$_.Exception.Message+' CUDA compatibility remains unverified. You may continue.')}finally{if($query){$query.Dispose()}}
}else{$warnings.Add('nvidia-smi was not found. NVIDIA GPU/driver compatibility is unknown. This backend requires CUDA; CPU mode is not implemented. You may continue.')}
if($InstallDir.Length-gt80){$warnings.Add('The chosen install path is long. PyTorch contains long filenames and can fail when Windows long-path support is unavailable. A path under 80 characters is recommended; choose a shorter folder if needed. This installer does not change Windows settings.')}
$drive=[IO.DriveInfo]::new([IO.Path]::GetPathRoot($InstallDir));if($drive.AvailableFreeSpace-lt30GB){$warnings.Add('Less than 30 GB free. Python, CUDA packages, model and temporary downloads can require substantial space.')}
Write-Host 'Kira Labs Voice Designer - FREE local original voice design'
Write-Host 'Downloads: Python (~11.4 MB), CUDA PyTorch/dependencies (several GB), and VoiceDesign model (4.52 GB). Internet is needed for setup only.'
Write-Host 'If required Microsoft Visual C++ runtime DLLs are missing, Setup downloads the signed Microsoft redistributable; Windows may request administrator approval. No automatic reboot or driver change occurs.'
Write-Host 'Reference tested backend: 32 GB RAM, RTX 5060 Ti 16 GB, Windows 11. Other configurations are not validated. NVIDIA driver must support CUDA 13.0.'
if($warnings.Count){foreach($w in $warnings){Write-Warning $w};if(!$AllowCompatibilityWarnings){if($NonInteractive){throw 'Compatibility warnings present. Rerun with -AllowCompatibilityWarnings to proceed.'};if((Read-Host 'Continue anyway? [y/N]')-notmatch'^(y|yes)$'){exit 2}}}
if(!$NonInteractive){if((Read-Host "Install into $InstallDir ? [Y/n]")-match'^(n|no)$'){exit 2}}
[IO.Directory]::CreateDirectory($InstallDir)|Out-Null
@{product='KiraLabs.VoiceDesigner';version='0.1.6-preview';root=$InstallDir}|ConvertTo-Json|Set-Content -LiteralPath $marker -Encoding UTF8
$data=Join-Path $InstallDir 'data';$cache=Join-Path $data 'cache\setup';[IO.Directory]::CreateDirectory($cache)|Out-Null
$manifest=Get-Content -LiteralPath (Join-Path $here 'provision-manifest.json') -Raw|ConvertFrom-Json
function Get-Sha256([string]$Path){
 $sha=[Security.Cryptography.SHA256]::Create();$stream=[IO.File]::OpenRead($Path)
 try{return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose();$sha.Dispose()}
}
[void][Reflection.Assembly]::LoadWithPartialName('System.IO.Compression')
[void][Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')
function Expand-Zip([string]$ArchiveFile,[string]$Destination){
 $base=[IO.Path]::GetFullPath($Destination).TrimEnd('\')+'\';[IO.Directory]::CreateDirectory($base)|Out-Null
 $zipArchive=[IO.Compression.ZipFile]::OpenRead($ArchiveFile)
 try{foreach($entry in $zipArchive.Entries){$target=[IO.Path]::GetFullPath((Join-Path $base $entry.FullName.Replace('/','\')));if(!$target.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)){throw 'Archive entry escaped installation folder.'};if(!$entry.Name){[IO.Directory]::CreateDirectory($target)|Out-Null;continue};[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))|Out-Null;$entryInput=$entry.Open();$entryOutput=[IO.File]::Open($target,[IO.FileMode]::Create,[IO.FileAccess]::Write);try{$entryInput.CopyTo($entryOutput)}finally{$entryOutput.Dispose();$entryInput.Dispose()}}}finally{$zipArchive.Dispose()}
}
function Get-File([string]$Url,[string]$Target,[string]$Sha){
 if((Test-Path -LiteralPath $Target)-and((Get-Sha256 $Target)-ieq$Sha)){Write-Host "Using verified cached download: $Target";return}
 if((Test-Path -LiteralPath ($Target+'.partial'))-and((Get-Sha256 ($Target+'.partial'))-ieq$Sha)){[IO.File]::Copy($Target+'.partial',$Target,$true);[IO.File]::Delete($Target+'.partial');Write-Host 'Recovered complete verified cached download.';return}
 Write-Host "Downloading $Url";Invoke-WebRequest -Uri $Url -OutFile ($Target+'.partial') -UseBasicParsing
 if((Get-Sha256 ($Target+'.partial'))-ine$Sha){throw "Download SHA-256 mismatch: $Url"};[IO.File]::Copy($Target+'.partial',$Target,$true);[IO.File]::Delete($Target+'.partial')
}
function Ensure-VisualCppRuntime {
 $required=@('vcruntime140.dll','vcruntime140_1.dll','msvcp140.dll')
 $system=Join-Path $env:SystemRoot 'System32';$missing=@();$unknown=@()
 foreach($dll in $required){try{[void][IO.File]::GetAttributes((Join-Path $system $dll))}catch{$cause=$_.Exception;while($cause.InnerException){$cause=$cause.InnerException};if($cause-is[IO.FileNotFoundException]-or$cause-is[IO.DirectoryNotFoundException]){$missing+=$dll}else{$unknown+=$dll}}}
 $vcVersion='registry version unavailable'
 try{$vc=Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' -ErrorAction Stop;if($vc.Version){$vcVersion=[string]$vc.Version}}catch{}
 if(!$missing.Count){if($unknown.Count){Write-Warning 'Some Microsoft runtime DLLs could not be inspected. No automatic redistributable is launched based on denied/unknown access; runtime compatibility remains unverified.'}else{Write-Host "Required x64 Microsoft Visual C++ runtime DLLs already present ($vcVersion); redistributable skipped."};return}
 Write-Host ('Required x64 Visual C++ DLLs are missing: '+($missing-join', '))
 $vcFile=Join-Path $cache 'vc_redist.x64.exe';$vcUrl='https://aka.ms/vc14/vc_redist.x64.exe'
 if(![IO.File]::Exists($vcFile)){Write-Host "Downloading Microsoft runtime from $vcUrl";Invoke-WebRequest -Uri $vcUrl -OutFile ($vcFile+'.partial') -UseBasicParsing;$verifyFile=$vcFile+'.partial'}else{$verifyFile=$vcFile}
 $signature=Get-AuthenticodeSignature -LiteralPath $verifyFile
 if($signature.Status-ne'Valid'-or!$signature.SignerCertificate-or$signature.SignerCertificate.Subject-notmatch'(^|,\s*)O=Microsoft Corporation(,|$)'){throw 'Microsoft redistributable signature/publisher could not be verified. No unverified runtime installer was run.'}
 if($verifyFile-ne$vcFile){[IO.File]::Copy($verifyFile,$vcFile,$true);[IO.File]::Delete($verifyFile)}
 Write-Host 'Starting Microsoft Visual C++ runtime installer. Windows may ask for administrator approval. No automatic reboot will occur.'
 $vcLog=Join-Path $cache 'vc-redist-install.log'
 $vcProcess=Start-Process -FilePath $vcFile -ArgumentList @('/install','/passive','/norestart','/log',('"'+$vcLog+'"')) -PassThru -Wait
 if($vcProcess.ExitCode-eq3010){$script:RestartRequired=$true;Write-Warning 'Microsoft runtime installation succeeded and requested a restart. This installer will not reboot Windows.'}
 elseif($vcProcess.ExitCode-ne0){throw ('Microsoft runtime installer returned '+$vcProcess.ExitCode+'. See '+$vcLog)}
 $stillMissing=@($required|Where-Object{![IO.File]::Exists((Join-Path $system $_))})
 if($stillMissing.Count-and!$script:RestartRequired){throw ('Required Microsoft runtime DLLs remain unavailable: '+($stillMissing-join', '))}
}
$script:RestartRequired=$false
Ensure-VisualCppRuntime
$runtime=Join-Path $InstallDir 'runtime';$python=Join-Path $runtime 'python.exe'
$zip=Join-Path $cache 'python-3.14.0-embed-amd64.zip';Get-File $manifest.python.url $zip $manifest.python.sha256
[IO.Directory]::CreateDirectory($runtime)|Out-Null;Expand-Zip $zip $runtime
$utf8=New-Object Text.UTF8Encoding $false
[IO.File]::WriteAllText((Join-Path $runtime 'python314._pth'),"python314.zip`r`n.`r`nLib\site-packages`r`n..\app`r`nimport site`r`n",$utf8)
$env:PYTHONNOUSERSITE='1';$env:PYTHONDONTWRITEBYTECODE='1';$env:PIP_DISABLE_PIP_VERSION_CHECK='1'
$env:PIP_CACHE_DIR=Join-Path $data 'cache\pip';$env:TEMP=Join-Path $data 'cache\temp';$env:TMP=$env:TEMP;[IO.Directory]::CreateDirectory($env:TEMP)|Out-Null
$log=Join-Path $data 'install.log'
$ErrorActionPreference='Continue'
Write-Host 'Installing isolated pip...'
$getpip=Join-Path $here 'get-pip.py';if((Get-Sha256 $getpip)-ine$manifest.pip_bootstrap.sha256){throw 'Bundled get-pip.py hash mismatch.'}
& $python $getpip --no-warn-script-location 2>&1|Tee-Object -FilePath $log -Append
if($LASTEXITCODE-ne0){throw "pip bootstrap failed. See $log"}
Write-Host 'Installing CUDA PyTorch and compatible audio package...'
& $python -m pip install --no-deps --no-warn-script-location --progress-bar on ('torch=='+$manifest.torch.version) ('torchaudio=='+$manifest.torchaudio.version) --index-url $manifest.torch.index 2>&1|Tee-Object -FilePath $log -Append
if($LASTEXITCODE-ne0){throw "PyTorch download/install failed. See $log"}
$soxWheel=Join-Path $here $manifest.bundled_wheels.sox.filename
if((Get-Sha256 $soxWheel)-ine$manifest.bundled_wheels.sox.sha256){throw 'Bundled pure-Python SoX wheel hash mismatch.'}
& $python -m pip install --no-warn-script-location --progress-bar on --find-links $here --only-binary=sox -r (Join-Path $here 'requirements-runtime.txt') 2>&1|Tee-Object -FilePath $log -Append
if($LASTEXITCODE-ne0){throw "Dependency installation failed. See $log"}
& $python -m pip install --no-deps --no-warn-script-location 'qwen-tts==0.1.1' 2>&1|Tee-Object -FilePath $log -Append
if($LASTEXITCODE-ne0){throw "Voice engine installation failed. See $log"}
Write-Host 'Installing application files...';Expand-Zip (Join-Path $here 'payload.zip') $InstallDir
Write-Host 'Downloading and verifying the fixed-revision local voice model...'
& $python (Join-Path $InstallDir 'app\download_models.py') --install-dir $InstallDir 2>&1|Tee-Object -FilePath $log -Append
if($LASTEXITCODE-ne0){throw "Model download failed. Rerun Setup to repair; existing saved voices are retained. See $log"}
& $python -m pip freeze|Set-Content -LiteralPath (Join-Path $data 'installed-packages.txt') -Encoding UTF8
Copy-Item -LiteralPath (Join-Path $here 'provision-manifest.json') -Destination (Join-Path $data 'provision-manifest.json') -Force
$ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe';$gui=Join-Path $InstallDir 'app\KiraLabs.VoiceDesigner.exe'
if(!$NoShortcuts){try{
$linkName='Kira Labs Voice Designer.lnk'
$shell=New-Object -ComObject WScript.Shell
$shortcutFolders=if($InstallDir.EndsWith('-Test')){@($InstallDir)}else{@([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))}
foreach($folder in $shortcutFolders){$link=$shell.CreateShortcut((Join-Path $folder $linkName));$link.TargetPath=$gui;$link.Arguments='';$link.WorkingDirectory=Split-Path -Parent $gui;$link.Description='Kira Labs Voice Designer';$link.Save()}
}catch{Write-Warning ('Shortcut creation unavailable: '+$_.Exception.Message+'. Use the app launch command in the installation folder.')}}
$uninstallLines=@('@echo off','if not exist "%~dp0app\Uninstall.ps1" (',' echo Voice Designer is already uninstalled. Created voices and data are preserved.',' exit /b 0',')','"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\Uninstall.ps1" %*','exit /b %errorlevel%')
[IO.File]::WriteAllText((Join-Path $InstallDir 'Uninstall.cmd'),[string]::Join([Environment]::NewLine,$uninstallLines),$utf8)
$launchLines=@('@echo off','if not exist "%~dp0app\KiraLabs.VoiceDesigner.exe" (',' echo Voice Designer is not installed. Run Setup.',' exit /b 1',')','start "" "%~dp0app\KiraLabs.VoiceDesigner.exe"')
[IO.File]::WriteAllText((Join-Path $InstallDir 'Kira Labs Voice Designer.cmd'),[string]::Join([Environment]::NewLine,$launchLines),$utf8)
try{
 $reg='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\KiraLabsVoiceDesigner'+$(if($InstallDir.EndsWith('-Test')){'Test'}else{''})
 New-Item -Path $reg -Force -ErrorAction Stop|Out-Null
 New-ItemProperty -Path $reg -Name DisplayName -Value 'Kira Labs Voice Designer' -PropertyType String -Force -ErrorAction Stop|Out-Null
 New-ItemProperty -Path $reg -Name Publisher -Value 'Kira Labs' -PropertyType String -Force -ErrorAction Stop|Out-Null
 New-ItemProperty -Path $reg -Name UninstallString -Value ('"'+$ps+'" -NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $InstallDir 'app\Uninstall.ps1')+'"') -PropertyType String -Force -ErrorAction Stop|Out-Null
 Write-Host 'Windows Installed Apps registration completed.'
}catch{Write-Warning ('Windows Installed Apps registration is unavailable: '+$_.Exception.Message+'. The app remains installed. Use '+(Join-Path $InstallDir 'Uninstall.cmd')+'. No registry permissions were changed.')}
Write-Host "Setup complete: $InstallDir. Saved voices and models stay in data/."
if($script:RestartRequired){Write-Warning 'Setup completed but a restart is required by the Microsoft runtime installer. Restart manually before opening the app.';exit 3010}
if(!$NoLaunch){Start-Process -FilePath $gui}
