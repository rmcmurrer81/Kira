$ErrorActionPreference='Stop'
$guiRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$candidateRoot=Split-Path -Parent $guiRoot
$source=(Get-Item -LiteralPath (Join-Path $guiRoot 'VoiceDesigner.cs')).FullName
$target=Join-Path $candidateRoot 'payload\app\KiraLabs.VoiceDesigner.exe'
if(Test-Path -LiteralPath $target){throw 'Preserve the existing GUI binary. Build in a fresh copy or choose a new candidate folder.'}
$compiler=Join-Path $env:SystemRoot 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$wpf=Join-Path $env:SystemRoot 'Microsoft.NET\Framework64\v4.0.30319\WPF'
& $compiler /nologo /target:winexe /optimize+ ('/out:'+$target) /reference:System.Web.Extensions.dll /reference:System.Xaml.dll ('/reference:'+(Join-Path $wpf 'PresentationFramework.dll')) ('/reference:'+(Join-Path $wpf 'PresentationCore.dll')) ('/reference:'+(Join-Path $wpf 'WindowsBase.dll')) $source
if($LASTEXITCODE-ne0){throw 'Native GUI compilation failed.'}
Get-FileHash -LiteralPath $target -Algorithm SHA256
