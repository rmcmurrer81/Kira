using System;
using System.IO;
using System.Linq;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Threading;
using System.Xml;
using System.Media;

// The desktop application. Its ordinary Python engine remains in the installed
// private runtime. No donor audio, system voice, remote API, or test harness.
class VoiceDesigner {
    static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    static readonly Encoding Utf8 = new UTF8Encoding(false);
    static Window window;
    static TextBox name, description, speech, seed;
    static TextBlock status;
    static Button generate, play, save, stop;
    static ProgressBar progress;
    static DispatcherTimer timer;
    static Process worker;
    static SoundPlayer player;
    static string app, install, data, logs, settings, stdout, stderr, wav;
    static object design;

    const string Xaml = @"<Window xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' Title='Kira Labs Voice Designer' Width='850' Height='790' MinWidth='720' MinHeight='650' Background='#F8F7FC' WindowStartupLocation='CenterScreen' FontFamily='Segoe UI'>
      <Window.Resources>
        <Style TargetType='Button'><Setter Property='Padding' Value='18,10'/><Setter Property='Margin' Value='0,0,10,0'/><Setter Property='Background' Value='#EAE3F4'/><Setter Property='Foreground' Value='#322044'/><Setter Property='BorderThickness' Value='0'/><Setter Property='FontSize' Value='14'/></Style>
        <Style TargetType='TextBox'><Setter Property='Padding' Value='12,10'/><Setter Property='FontSize' Value='15'/><Setter Property='BorderBrush' Value='#D8CCE8'/></Style>
      </Window.Resources>
      <Grid Margin='30'><Grid.RowDefinitions><RowDefinition Height='Auto'/><RowDefinition Height='*'/><RowDefinition Height='Auto'/></Grid.RowDefinitions>
        <StackPanel><TextBlock Text='KIRA LABS' Foreground='#7950B3' FontWeight='Bold'/><TextBlock Text='Design a voice of your own.' FontSize='30' FontWeight='SemiBold' Foreground='#28183E' Margin='0,8,0,5'/><TextBlock Text='Describe an original adult voice. Generate locally. Listen and keep the WAV.' Foreground='#62576F' FontSize='15'/></StackPanel>
        <ScrollViewer Grid.Row='1' VerticalScrollBarVisibility='Auto' Margin='0,20,0,15'><StackPanel>
          <TextBlock Text='VOICE NAME'/><TextBox x:Name='VoiceName' AutomationProperties.Name='Voice name' Text='My original voice' MaxLength='80'/>
          <TextBlock Text='DESCRIBE THE VOICE' Margin='0,15,0,7'/><TextBox x:Name='Description' AutomationProperties.Name='Voice description' Height='105' AcceptsReturn='True' TextWrapping='Wrap' MaxLength='600' Text='An original adult woman with a warm, clear middle register, relaxed conversational pacing, natural English pronunciation, and thoughtful expression.'/>
          <TextBlock Text='WHAT SHOULD IT SAY?' Margin='0,15,0,7'/><TextBox x:Name='Speech' AutomationProperties.Name='Sample speech' Height='95' AcceptsReturn='True' TextWrapping='Wrap' MaxLength='300' Text='Hello! This is my new original voice. I am glad to meet you.'/>
          <Grid Margin='0,14,0,0'><Grid.ColumnDefinitions><ColumnDefinition Width='150'/><ColumnDefinition Width='*'/></Grid.ColumnDefinitions><StackPanel><TextBlock Text='SEED'/><TextBox x:Name='Seed' AutomationProperties.Name='Seed' Text='1161003' Margin='0,5,14,0'/></StackPanel><TextBlock Grid.Column='1' Text='The description and seed provide best-effort continuity. Listen to each result; identical speaker identity is not guaranteed.' TextWrapping='Wrap' VerticalAlignment='Center' Foreground='#73687F' FontSize='12'/></Grid>
          <StackPanel Orientation='Horizontal' Margin='0,20,0,12'><Button x:Name='Generate' Content='Generate voice' Background='#6B3BB5' Foreground='White'/><Button x:Name='Play' Content='Play' IsEnabled='False'/><Button x:Name='Save' Content='Save WAV...' IsEnabled='False'/><Button x:Name='Stop' Content='Stop playback' IsEnabled='False'/></StackPanel>
        </StackPanel></ScrollViewer>
        <StackPanel Grid.Row='2'><ProgressBar x:Name='Progress' Height='5' Foreground='#8457C6'/><TextBlock x:Name='Status' Text='Ready. Nothing is uploaded during generation.' TextWrapping='Wrap' Margin='0,12,0,16'/><TextBlock Text='LOCAL &amp; ORIGINAL — No donor recordings, cloning, or system-voice fallback' FontWeight='SemiBold' Foreground='#665776'/><TextBlock Text='Synthetic audio. Do not imitate real people or existing characters.' Foreground='#80748D' FontSize='12' Margin='0,7,0,0'/></StackPanel>
      </Grid></Window>";

    static string Quote(string value) {
        var result = new StringBuilder("\""); int slashes = 0;
        foreach (char c in value) {
            if (c == '\\') { slashes++; continue; }
            if (c == '"') { result.Append('\\', slashes * 2 + 1); result.Append('"'); slashes = 0; continue; }
            result.Append('\\', slashes); result.Append(c); slashes = 0;
        }
        result.Append('\\', slashes * 2); result.Append('"'); return result.ToString();
    }
    static TextBox Box(string id) { return (TextBox)window.FindName(id); }
    static Button Button(string id) { return (Button)window.FindName(id); }
    static void Restore() {
        if (!File.Exists(settings)) return;
        try {
            var s = Json.Deserialize<Dictionary<string, object>>(File.ReadAllText(settings));
            name.Text = Convert.ToString(s["name"]); description.Text = Convert.ToString(s["description"]);
            speech.Text = Convert.ToString(s["text"]); seed.Text = Convert.ToString(s["seed"]);
        } catch { status.Text = "Previous settings could not be restored. Enter a new design."; }
    }
    static void Generate(object sender, RoutedEventArgs e) {
        bool started = false;
        try {
            long number;
            if (!Int64.TryParse(seed.Text, out number) || number < 0) throw new Exception("Enter a nonnegative whole-number seed.");
            if (String.IsNullOrWhiteSpace(description.Text) || String.IsNullOrWhiteSpace(speech.Text)) throw new Exception("Enter a description and sample text.");
            if (player != null) player.Stop();
            var request = new Dictionary<string, object> { {"name", name.Text.Trim()}, {"description", description.Text.Trim()}, {"text", speech.Text.Trim()}, {"seed", number} };
            string raw = Json.Serialize(request); File.WriteAllText(settings, raw, Utf8);
            string id = Guid.NewGuid().ToString("N"); string req = Path.Combine(logs, id + ".request.json");
            File.WriteAllText(req, raw, Utf8); stdout = Path.Combine(logs, id + ".out.log"); stderr = Path.Combine(logs, id + ".error.log");
            File.WriteAllText(stdout, "", Utf8); File.WriteAllText(stderr, "", Utf8);
            var psi = new ProcessStartInfo(Path.Combine(install, "runtime", "python.exe"), "-B " + Quote(Path.Combine(app, "voice_cli.py")) + " --request " + Quote(req));
            psi.UseShellExecute = false; psi.CreateNoWindow = true; psi.WorkingDirectory = app; psi.RedirectStandardOutput = true; psi.RedirectStandardError = true;
            var outputLock = new object(); var errorLock = new object();
            worker = new Process(); worker.StartInfo = psi;
            worker.OutputDataReceived += delegate(object s, DataReceivedEventArgs line) { if (line.Data != null) lock(outputLock) { File.AppendAllText(stdout, line.Data + Environment.NewLine, Utf8); } };
            worker.ErrorDataReceived += delegate(object s, DataReceivedEventArgs line) { if (line.Data != null) lock(errorLock) { File.AppendAllText(stderr, line.Data + Environment.NewLine, Utf8); } };
            worker.Start(); started = true;
            worker.BeginOutputReadLine(); worker.BeginErrorReadLine();
            generate.IsEnabled = play.IsEnabled = save.IsEnabled = stop.IsEnabled = false; wav = null; design = null;
            progress.IsIndeterminate = true; status.Text = "Generating locally. Please wait. Model loading and generation have a five-minute timeout."; timer.Start();
        } catch (Exception ex) {
            if (worker != null && !started) { worker.Dispose(); worker = null; }
            if (worker != null && started) {
                generate.IsEnabled = play.IsEnabled = save.IsEnabled = stop.IsEnabled = false;
                progress.IsIndeterminate = true; timer.Start();
                status.Text = "The engine started but its output could not be opened. Wait for it to finish; details remain in data/logs. " + ex.Message;
            } else status.Text = ex.Message;
        }
    }
    static void Tick(object sender, EventArgs e) {
        if (worker == null || !worker.HasExited) return;
        worker.WaitForExit(); int exit = worker.ExitCode; worker.Dispose(); worker = null;
        timer.Stop(); generate.IsEnabled = true; progress.IsIndeterminate = false;
        if (exit != 0) { status.Text = "Generation failed. The request and error log are retained in the data/logs folder. See Troubleshooting in the guide."; return; }
        try {
            string last = File.ReadLines(stdout).Last(line => !String.IsNullOrWhiteSpace(line));
            var result = Json.Deserialize<Dictionary<string, object>>(last);
            wav = Convert.ToString(result["wav"]); design = result["design"];
            if (!File.Exists(wav)) throw new Exception("The engine did not return an audio file.");
            play.IsEnabled = save.IsEnabled = true; status.Text = "Your voice is ready. Play it, then save a copy if you like it.";
        } catch (Exception ex) { status.Text = ex.Message; }
    }
    static void Play(object sender, RoutedEventArgs e) {
        try { if (player != null) { player.Stop(); player.Dispose(); } player = new SoundPlayer(wav); player.Play(); stop.IsEnabled = true; status.Text = "Playing through your Windows default audio output."; }
        catch (Exception ex) { status.Text = ex.Message; }
    }
    static void Save(object sender, RoutedEventArgs e) {
        try {
            string safe = String.Concat(name.Text.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c)).Trim();
            if (safe.Length == 0) safe = "My original voice";
            var d = new Microsoft.Win32.SaveFileDialog { Filter = "WAV audio (*.wav)|*.wav", FileName = safe + ".wav", AddExtension = true, DefaultExt = ".wav", OverwritePrompt = true };
            if (d.ShowDialog(window) != true) return;
            File.Copy(wav, d.FileName, true); File.WriteAllText(Path.ChangeExtension(d.FileName, ".voice.json"), Json.Serialize(design), Utf8);
            status.Text = "Saved the WAV and design settings.";
        } catch (Exception ex) { status.Text = ex.Message; }
    }
    [STAThread] static int Main() {
        try {
            app = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
            install = Directory.GetParent(app).FullName; data = Path.Combine(install, "data"); logs = Path.Combine(data, "logs"); settings = Path.Combine(data, "last-design.json"); Directory.CreateDirectory(logs);
            var application = new Application(); application.ShutdownMode = ShutdownMode.OnMainWindowClose;
            using (var reader = XmlReader.Create(new StringReader(Xaml))) window = (Window)XamlReader.Load(reader);
            name = Box("VoiceName"); description = Box("Description"); speech = Box("Speech"); seed = Box("Seed");
            status = (TextBlock)window.FindName("Status"); progress = (ProgressBar)window.FindName("Progress"); generate = Button("Generate"); play = Button("Play"); save = Button("Save"); stop = Button("Stop");
            timer = new DispatcherTimer(); timer.Interval = TimeSpan.FromMilliseconds(350); timer.Tick += Tick;
            generate.Click += Generate; play.Click += Play; save.Click += Save; stop.Click += delegate { if (player != null) player.Stop(); status.Text = "Playback stopped."; };
            Restore();
            if (!File.Exists(Path.Combine(install, "runtime", "python.exe"))) { generate.IsEnabled = false; status.Text = "Run Setup to install the local engine and model."; }
            window.Closing += delegate(object s, System.ComponentModel.CancelEventArgs e) { if (worker != null && !worker.HasExited) { e.Cancel = true; MessageBox.Show(window, "Generation is still running. Wait for it to finish or reach its five-minute timeout before closing.", "Voice Designer"); return; } if (player != null) { player.Stop(); player.Dispose(); } timer.Stop(); };
            application.Run(window); return 0;
        } catch (Exception ex) { MessageBox.Show(ex.Message, "Voice Designer could not start"); return 1; }
    }
}
