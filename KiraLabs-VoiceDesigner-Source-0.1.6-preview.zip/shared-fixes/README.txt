Shared managed-runtime fix — corrected review snapshot

The optional VideoStudio convenience mapping now treats blank per-file settings as unset, preserves explicit installed_root/runtime-root selection, and prevents the legacy host-interpreter compatibility route from replacing an explicit root. Nonblank per-file overrides still win.

The reviewed fix is applied in VideoStudio commit40c8b71abd0336a2c9bc4856e15e6fd8e9157577. Seven focused path-selection checks passed; no new model-generation or GUI qualification follows. Apply this snapshot only to the recorded old source hash; an already updated checkout needs no second application. Exact CRLF replacements are in the JSON; the readable diff normalizes line endings.

The standalone tool already supplies explicit private Python/model paths, so its backend behavior does not depend on this optional patch. Models, neutral delivery, project stores and identity limitations are unchanged. The older Chatterbox narration endpoint is not unified by this change. Keep each project's data separate.

Native GUI/source installer validation is documented separately in the release pack. No private books, memories, recordings, host package paths or test-capture implementation are shipped.
