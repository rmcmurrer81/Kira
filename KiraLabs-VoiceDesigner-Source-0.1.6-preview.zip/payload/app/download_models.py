from pathlib import Path
import argparse,json,hashlib,urllib.request,sys

def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--install-dir',type=Path,required=True);a=p.parse_args();root=a.install_dir.resolve();model=root/'data/models/Qwen3-TTS-12Hz-1.7B-VoiceDesign'
 manifest=json.loads((root/'app/kira_studio/voice_assets/qwen3_voice_design_inventory.json').read_text(encoding='utf-8'))['model_manifest']
 for i,item in enumerate(manifest['files'],1):
  rel=Path(item['path']);assert not rel.is_absolute()and'..'not in rel.parts
  target=model/rel;target.parent.mkdir(parents=True,exist_ok=True)
  if target.is_file()and target.stat().st_size==item['bytes']and digest(target)==item['sha256']:print(f"[{i}/11] Already verified: {rel}",flush=True);continue
  url='https://huggingface.co/Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign/resolve/'+manifest['revision']+'/'+rel.as_posix()
  part=target.with_suffix(target.suffix+'.partial');received=0;h=hashlib.sha256();report=-1
  with urllib.request.urlopen(url,timeout=120)as response,part.open('wb')as f:
   while True:
    b=response.read(1024*1024)
    if not b:break
    f.write(b);received+=len(b);h.update(b);pct=int(received*100/max(1,item['bytes']))
    if pct!=report:print(f"[{i}/11] {rel}: {pct}% ({received:,}/{item['bytes']:,} bytes)",flush=True);report=pct
  if received!=item['bytes']or h.hexdigest()!=item['sha256']:raise RuntimeError('Model download size/SHA mismatch: '+str(rel))
  part.replace(target)
 print('All 11 core model files downloaded and SHA-256 verified.',flush=True)
 return 0
if __name__=='__main__':raise SystemExit(main())
