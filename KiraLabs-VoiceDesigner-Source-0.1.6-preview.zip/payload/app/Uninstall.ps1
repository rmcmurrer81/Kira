param([switch]$NonInteractive)
$ErrorActionPreference='Stop'
$app=Split-Path -Parent $MyInvocation.MyCommand.Path
$root=[IO.Path]::GetFullPath((Split-Path -Parent $app)).TrimEnd('\')
$base=[IO.Path]::GetFullPath((Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'KiraLabs'))
$profileBase=[IO.Path]::GetFullPath((Join-Path (Join-Path $env:USERPROFILE 'AppData\Local') 'KiraLabs'))
$allowedParents=@($base,$profileBase)
if([IO.Path]::GetFileName($root)-notin@('VoiceDesigner','VoiceDesigner-Test')){throw 'Uninstall root must be the owned VoiceDesigner or VoiceDesigner-Test folder.'}
if((Get-Item -LiteralPath $root -Force).Attributes-band[IO.FileAttributes]::ReparsePoint){throw 'Refusing to uninstall through a linked root directory.'}
$marker=Join-Path $root '.kiralabs-voice-designer.json'
$m=Get-Content -LiteralPath $marker -Raw|ConvertFrom-Json
if($m.product-ne'KiraLabs.VoiceDesigner'-or[IO.Path]::GetFullPath($m.root).TrimEnd('\')-ine$root){throw 'Owned-installation marker mismatch.'}
if(!$NonInteractive){Write-Host "Uninstall application/runtime from $root. Saved voices, models, logs and cache in data/ are preserved.";if((Read-Host 'Continue? [y/N]')-notmatch'^(y|yes)$'){exit 2}}
$linkName='Kira Labs Voice Designer.lnk'
$shortcutFolders=if($root.EndsWith('-Test')){@($root)}else{@([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))}
try{$shell=New-Object -ComObject WScript.Shell
foreach($folder in $shortcutFolders){$link=Join-Path $folder $linkName;if(Test-Path -LiteralPath $link){$s=$shell.CreateShortcut($link);$native=Join-Path $root 'app\KiraLabs.VoiceDesigner.exe';$legacy=Join-Path $root 'app\VoiceDesigner.ps1';if($s.TargetPath-ieq$native-or$s.Arguments.Contains($legacy)){Remove-Item -LiteralPath $link -Force}}}
}catch{Write-Warning ('Optional shortcut removal unavailable: '+$_.Exception.Message+'. Owned app/runtime removal will continue.')}
$reg='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\KiraLabsVoiceDesigner'+$(if($root.EndsWith('-Test')){'Test'}else{''});try{if(Test-Path -LiteralPath $reg -ErrorAction Stop){$entry=Get-ItemProperty -LiteralPath $reg -ErrorAction Stop;if($entry.UninstallString.Contains((Join-Path $root 'app\Uninstall.ps1'))){Remove-Item -LiteralPath $reg -Recurse -Force -ErrorAction Stop}}}catch{Write-Warning ('Optional Windows registration removal unavailable: '+$_.Exception.Message+'. Owned app/runtime removal will continue. No registry permissions changed.')}
foreach($name in @('runtime','app')){
 $target=[IO.Path]::GetFullPath((Join-Path $root $name));if([IO.Path]::GetDirectoryName($target)-ine$root){throw 'Uninstall containment mismatch.'}
 if(Test-Path -LiteralPath $target){$item=Get-Item -LiteralPath $target -Force;if($item.Attributes-band[IO.FileAttributes]::ReparsePoint){throw 'Refusing to traverse a linked application/runtime directory.'};Remove-Item -LiteralPath $target -Recurse -Force}
}
@{product='KiraLabs.VoiceDesigner';root=$root;status='uninstalled_data_preserved'}|ConvertTo-Json|Set-Content -LiteralPath $marker -Encoding UTF8
Write-Host "Uninstalled. Created voices, downloaded models and cache remain in $root\data. Rerun Setup to reinstall."
