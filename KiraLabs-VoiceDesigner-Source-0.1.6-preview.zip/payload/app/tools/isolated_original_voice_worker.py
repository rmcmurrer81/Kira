"""One-process worker for a hash-bound Video Studio original-voice job."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import random
import shutil
import sys
import time
import uuid
import wave
from datetime import datetime, timezone


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--build-root", type=Path, required=True)
    parser.add_argument("--runtime-root", type=Path, required=True)
    parser.add_argument("--job", type=Path, required=True)
    parser.add_argument("--job-file-sha256", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--model-path", type=Path, required=True)
    parser.add_argument("--model-inventory", type=Path, required=True)
    parser.add_argument("--cache-root", type=Path, required=True)
    return parser.parse_args()


def _write_new_file(path: Path, data: bytes) -> None:
    with path.open("xb") as target:
        target.write(data)
        target.write(b"\n")
        target.flush()
        os.fsync(target.fileno())


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace(
        "+00:00", "Z"
    )


def main() -> int:
    args = parse_args()
    worker_run_id = str(uuid.uuid4())
    worker_started_at = _utc_now()
    build_root = args.build_root.expanduser().resolve()
    runtime_root = args.runtime_root.expanduser().resolve()
    job_path = args.job.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()
    model_path = args.model_path.expanduser().resolve()
    model_inventory_path = args.model_inventory.expanduser().resolve()
    cache_root = args.cache_root.expanduser().resolve()

    # Import the Studio-owned validator, never executable code from the runtime
    # root.  Validation occurs before CUDA or model imports.
    sys.path.insert(0, str(build_root))
    import kira_studio.original_voice as studio_original_voice  # pylint: disable=import-outside-toplevel
    from kira_studio.original_voice import (  # pylint: disable=import-outside-toplevel
        CONTINUITY_LABEL,
        ENGINE_NAME,
        RECEIPT_KIND,
        canonical_json_bytes,
        file_artifact,
        file_sha256,
        load_model_inventory_reference,
        validate_voice_job,
    )

    worker_artifact = file_artifact(Path(__file__))
    studio_module_artifact = file_artifact(Path(studio_original_voice.__file__))
    executable_artifact = file_artifact(Path(sys.executable))

    if output_dir.exists():
        raise RuntimeError("Refusing to overwrite an existing original-voice output.")
    try:
        raw_job_bytes = job_path.read_bytes()
    except OSError as exc:
        raise RuntimeError("Original-voice job is unreadable.") from exc
    if hashlib.sha256(raw_job_bytes).hexdigest() != args.job_file_sha256:
        raise RuntimeError("Original-voice job file hash mismatch.")
    try:
        raw_job = json.loads(raw_job_bytes.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("Original-voice job is unreadable.") from exc
    job = validate_voice_job(raw_job, runtime_root=runtime_root)

    if not model_path.is_dir():
        raise RuntimeError("The configured local Qwen VoiceDesign model is missing.")
    model_binding = load_model_inventory_reference(model_path, model_inventory_path)
    cache_root.mkdir(parents=True, exist_ok=True)
    cache_paths = {
        name: cache_root / name
        for name in ("temp", "numba", "huggingface", "torch", "inductor", "extensions")
    }
    for path in cache_paths.values():
        path.mkdir(parents=True, exist_ok=True)
    os.environ.update(
        {
            "HF_HUB_OFFLINE": "1",
            "TRANSFORMERS_OFFLINE": "1",
            "HF_HUB_DISABLE_TELEMETRY": "1",
            "TOKENIZERS_PARALLELISM": "false",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONNOUSERSITE": "1",
            "CUDA_VISIBLE_DEVICES": "0",
            "NUMBA_CACHE_DIR": str(cache_paths["numba"]),
            "HF_HOME": str(cache_paths["huggingface"]),
            "TORCH_HOME": str(cache_paths["torch"]),
            # A deliberately sanitized child environment does not carry the
            # Windows USERNAME variable.  Give Torch explicit device-local
            # cache roots so it never falls through getpass to the POSIX-only
            # ``pwd`` module while importing Dynamo/Inductor helpers.
            "TORCHINDUCTOR_CACHE_DIR": str(cache_paths["inductor"]),
            "TORCH_EXTENSIONS_DIR": str(cache_paths["extensions"]),
            "TEMP": str(cache_paths["temp"]),
            "TMP": str(cache_paths["temp"]),
        }
    )

    # Explicit installed package roots keep the interpreter isolated from implicit
    # user-site startup while supporting a Studio-owned compatibility runtime.
    package_roots = json.loads(os.environ.get("KIRA_ORIGINAL_VOICE_PACKAGE_PATHS", "[]"))
    if not isinstance(package_roots, list) or len(package_roots) > 8:
        raise RuntimeError("Invalid installed voice package roots.")
    normalized_package_roots = []
    for value in package_roots:
        if not isinstance(value, str) or not Path(value).is_absolute() or not Path(value).is_dir():
            raise RuntimeError("An installed voice package root is missing or invalid.")
        normalized_package_roots.append(str(Path(value).resolve()))
    for value in reversed(normalized_package_roots):
        sys.path.insert(0, value)

    import numpy as np  # pylint: disable=import-outside-toplevel
    import torch  # pylint: disable=import-outside-toplevel
    from qwen_tts import Qwen3TTSModel  # pylint: disable=import-outside-toplevel

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable; original-voice generation was not attempted.")
    seed = int(job["seed"])
    random.seed(seed)
    np.random.seed(seed % (2**32 - 1))
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    started = time.time()
    model = Qwen3TTSModel.from_pretrained(
        str(model_path),
        device_map="cuda:0",
        dtype=torch.bfloat16,
        attn_implementation="sdpa",
        local_files_only=True,
    )
    loaded = time.time()
    waves, sample_rate = model.generate_voice_design(
        text=job["text"],
        language=job["runtime_contract"]["language"],
        instruct=job["synthesis_instruction"],
    )
    torch.cuda.synchronize(0)
    generated = time.time()

    if not isinstance(waves, (list, tuple)) or len(waves) != 1:
        raise RuntimeError("VoiceDesign returned an unexpected candidate count.")
    samples = np.asarray(waves[0], dtype=np.float32).reshape(-1)
    if samples.size == 0 or not np.isfinite(samples).all():
        raise RuntimeError("VoiceDesign returned empty or non-finite audio.")
    pcm = np.rint(np.clip(samples, -1.0, 1.0) * 32767.0).astype("<i2")
    duration = float(pcm.size) / float(sample_rate or 1)
    peak = int(np.max(np.abs(pcm.astype(np.int32))))
    rms = float(math.sqrt(float(np.mean(np.square(pcm.astype(np.float64))))))
    clipped = float(np.mean(np.abs(pcm.astype(np.int32)) >= 32766))
    if int(sample_rate) != 24_000 or not 0.25 <= duration <= 30.0:
        raise RuntimeError("Generated audio format or duration is outside the private-preview boundary.")
    if peak < 32 or rms < 8.0 or clipped > 0.01:
        raise RuntimeError("Generated audio signal failed validation.")

    output_dir.parent.mkdir(parents=True, exist_ok=True)
    stage = output_dir.parent / f".{output_dir.name}.stage-{uuid.uuid4().hex}"
    stage.mkdir(parents=False, exist_ok=False)
    try:
        audio_path = stage / "voice.wav"
        with wave.open(str(audio_path), "wb") as wav_file:
            wav_file.setnchannels(1)
            wav_file.setsampwidth(2)
            wav_file.setframerate(int(sample_rate))
            wav_file.writeframes(pcm.tobytes())
        audio_sha256 = file_sha256(audio_path)
        worker_ended_at = _utc_now()
        exact_command = [
            executable_artifact["path"],
            "-B",
            worker_artifact["path"],
            "--build-root",
            str(build_root),
            "--runtime-root",
            str(runtime_root),
            "--job",
            str(job_path),
            "--job-file-sha256",
            args.job_file_sha256,
            "--output-dir",
            str(output_dir),
            "--model-path",
            str(model_path),
            "--model-inventory",
            str(model_inventory_path),
            "--cache-root",
            str(cache_root),
        ]
        receipt = {
            "schema_version": 1,
            "record_kind": RECEIPT_KIND,
            "status": "generated_unreviewed_private_preview",
            "job_id": f"voice-{job['job_sha256'][:20]}",
            "job_sha256": job["job_sha256"],
            "canonical_request_sha256": job["job_sha256"],
            "job_file_sha256": args.job_file_sha256,
            "character_id": job["character_id"],
            "attempt_id": job["attempt_id"],
            "profile_id": job["profile"]["profile_id"],
            "text_sha256": job["text_sha256"],
            "seed": seed,
            "delivery_preset": job["performance"]["preset"],
            "direction_sha256": job["performance"]["direction_sha256"],
            "identity_binding_sha256": job["identity_binding_sha256"],
            "exact_request": {
                "text": job["text"],
                "text_sha256": job["text_sha256"],
                "synthesis_instruction": job["synthesis_instruction"],
                "synthesis_instruction_sha256": hashlib.sha256(
                    job["synthesis_instruction"].encode("utf-8")
                ).hexdigest(),
                "delivery_direction": job["performance"]["direction"],
                "delivery_direction_sha256": job["performance"]["direction_sha256"],
                "seed": seed,
            },
            "request_artifact": file_artifact(job_path),
            "generator": {
                "worker_script": worker_artifact,
                "studio_module": studio_module_artifact,
            },
            "runtime": {
                "executable": executable_artifact,
                "backend": {
                    "module": "qwen_tts",
                    "class": "Qwen3TTSModel",
                    "method": "generate_voice_design",
                    "qwen_tts_version": importlib.metadata.version("qwen-tts"),
                    "torch_version": str(torch.__version__),
                    "cuda_runtime_version": str(torch.version.cuda or "unreported"),
                },
            },
            "dependency_packages": {
                "explicit_roots": normalized_package_roots,
                "qwen_tts_module": file_artifact(Path(sys.modules["qwen_tts"].__file__)),
                "torch_module": file_artifact(Path(torch.__file__)),
                "transformers_module": file_artifact(Path(sys.modules["transformers"].__file__)),
            },
            "model_binding": model_binding,
            "execution": {
                "worker_run_id": worker_run_id,
                "started_at_utc": worker_started_at,
                "ended_at_utc": worker_ended_at,
                "exact_command": exact_command,
                "paths": {
                    "build_root": str(build_root),
                    "runtime_root": str(runtime_root),
                    "job_path": str(job_path),
                    "output_dir": str(output_dir),
                    "model_path": str(model_path),
                    "model_inventory_path": str(model_inventory_path),
                    "cache_root": str(cache_root),
                },
                "settings": {
                    "operation": "generate_voice_design",
                    "language": job["runtime_contract"]["language"],
                    "seed": seed,
                    "device_map": "cuda:0",
                    "dtype": "torch.bfloat16",
                    "attention_implementation": "sdpa",
                    "local_files_only": True,
                    "candidate_count": 1,
                },
                "device": {
                    "requested": "cuda:0",
                    "resolved_name": torch.cuda.get_device_name(0),
                },
                "model_load_completed": True,
                "generation_completed": True,
            },
            "speaker_continuity": CONTINUITY_LABEL,
            "speaker_identity_guaranteed": False,
            "model": ENGINE_NAME,
            "device": torch.cuda.get_device_name(0),
            "sample_rate_hz": int(sample_rate),
            "sample_count": int(pcm.size),
            "duration_seconds": round(duration, 6),
            "peak_pcm16": peak,
            "rms_pcm16": round(rms, 6),
            "clipped_fraction": round(clipped, 9),
            "model_load_seconds": round(loaded - started, 3),
            "generation_seconds": round(generated - loaded, 3),
            "audio_sha256": audio_sha256,
            "output_wav": {
                "path": str(output_dir / "voice.wav"),
                "relative_path": "voice.wav",
                "size_bytes": audio_path.stat().st_size,
                "sha256": audio_sha256,
            },
            "offline_mode": True,
            "network_used": False,
            "reference_audio_used": False,
            "speaker_embedding_used": False,
            "voice_cloning_used": False,
            "named_imitation_used": False,
            "playback_performed": False,
            "automatic_assignment_performed": False,
            "activation_performed": False,
            "publication_performed": False,
        }
        _write_new_file(stage / "runtime.receipt.json", canonical_json_bytes(receipt))
        stage.rename(output_dir)
    except BaseException:
        shutil.rmtree(stage, ignore_errors=True)
        raise
    finally:
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
