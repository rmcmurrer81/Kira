"""Studio-owned original voice designs and short auditions using installed weights."""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import threading
import uuid

from .original_voice import (
    CATALOG_ID, ENGINE_NAME, MODEL_RELATIVE, OriginalVoiceError, OriginalVoiceService,
    RUNTIME_PYTHON_WINDOWS_RELATIVE, canonical_json_bytes, file_sha256,
    load_model_inventory_reference, normalize_delivery_preset,
    OWNER_REJECTED_DELIVERY_PRESETS,
)
from .store import StudioError, now

MAX_AUDITION_TEXT = 300
IDENTITY_CONSTRAINTS = {
    'original_text_style_only': True,
    'reference_audio_allowed': False, 'speaker_embedding_allowed': False,
    'donor_voice_allowed': False, 'voice_cloning_allowed': False,
    'named_real_person_imitation_allowed': False,
    'existing_character_imitation_allowed': False,
    'real_person_or_character_identity_claim_allowed': False,
}


def _text(value, label, maximum):
    if not isinstance(value, str) or not value.strip() or len(value.strip()) > maximum:
        raise StudioError(f'{label} must contain 1 to {maximum} characters.')
    text = value.strip()
    if any(ord(char) < 32 and char not in '\n\r\t' for char in text):
        raise StudioError(f'{label} contains unsupported control characters.')
    return text


def discover_voice_runtime(build_root: Path, environment=None, *, installed_root=None):
    env=dict(os.environ if environment is None else environment)
    base=Path(build_root).resolve().parent
    model=Path(env.get('KIRA_ORIGINAL_VOICE_MODEL_PATH') or base/'data/models/Qwen3-TTS-12Hz-1.7B-VoiceDesign')
    python=Path(env.get('KIRA_ORIGINAL_VOICE_PYTHON') or base/'runtime/python.exe')
    inventory=Path(build_root)/'kira_studio/voice_assets/qwen3_voice_design_inventory.json'
    result={'available':False,'engine':ENGINE_NAME,'python':str(python),'model':str(model),'inventory':str(inventory),'package_paths':[],'model_inference':False,'downloads_performed':0,'personal_profiles_read':False,'kira_world_app_required':False}
    try:
        if not python.is_file():raise OriginalVoiceError('Run the installer to finish setting up Python.')
        result['model_binding']=load_model_inventory_reference(model,inventory)
    except OriginalVoiceError as exc:
        result['message']=str(exc);return result
    result.update(available=True,message='Ready for a local original voice design.')
    return result


class StudioVoiceService:
    """Each voice belongs to one project and uses an immutable private catalog."""

    def __init__(self, store, build_root, *, environment=None, runtime=None, service_factory=OriginalVoiceService):
        self.store = store
        self.build_root = Path(build_root).resolve()
        self.environment = dict(os.environ if environment is None else environment)
        self._runtime = runtime
        self.service_factory = service_factory
        self.lock = threading.RLock()
        self.active = False

    def runtime(self):
        return deepcopy(self._runtime) if self._runtime is not None else discover_voice_runtime(self.build_root, self.environment)

    def list(self, project_id):
        project = self.store.project(project_id)
        runtime = self.runtime()
        return {'project_id': project_id, 'voices': deepcopy(project.get('studio_voices', [])),
            'runtime': {key: runtime.get(key) for key in ('available', 'engine', 'message', 'model_inference', 'kira_world_app_required')},
            'active': self.active, 'assets': deepcopy([a for a in project.get('assets', []) if a.get('studio_voice_id')])}

    def create(self, project_id, payload):
        if set(payload) - {'name', 'description'}:
            raise StudioError('A new original voice accepts only its name and description.')
        name = _text(payload.get('name'), 'Voice name', 80)
        description = _text(payload.get('description'), 'Voice description', 600)
        with self.lock:
            project = self.store.project(project_id)
            voice_id = 'voice-' + uuid.uuid4().hex[:12]
            seed = int.from_bytes(uuid.uuid4().bytes[:4], 'big')
            style = ('Create an original adult voice described as follows: ' + description +
                ' Use a new vocal identity, without imitating a named person or existing character.')
            profile = {'profile_id': voice_id, 'label': name, 'voice_presentation': 'original adult',
                'register': 'as described', 'cadence': 'as described', 'style_instruction': style,
                'traits': ['original', 'adult', 'description-directed'], 'identity_constraints': dict(IDENTITY_CONSTRAINTS)}
            catalog = {'schema_version': 1, 'record_type': 'STABLE_ORIGINAL_NONIMITATION_VOICE_PROFILE_CATALOG',
                'catalog_id': CATALOG_ID, 'state': 'STATIC_STYLE_DESIGNS_ONLY_UNSYNTHESIZED', 'profiles': [profile]}
            catalog_relative = Path('studio_voice_designs') / voice_id
            path = self.store.state_dir / catalog_relative / 'Voice/profiles/stable_original_voice_profiles_v1.json'
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as file:
                file.write(canonical_json_bytes(catalog))
            record = {'voice_id': voice_id, 'project_id': project_id, 'name': name, 'description': description,
                'seed': seed, 'profile_id': voice_id, 'catalog_relative': catalog_relative.as_posix(),
                'catalog_sha256': file_sha256(path), 'created_at': now(), 'auditions': [],
                'engine': ENGINE_NAME, 'source': 'studio_original_voice_design', 'personal_profile_copied': False,
                'speaker_identity_guaranteed': False, 'assigned_to_character': False}
            project.setdefault('studio_voices', []).append(record)
            project['updated_at'] = now()
            self.store._save('studio_original_voice_created')
            return deepcopy(record)

    def audition(self, project_id, voice_id, payload):
        if set(payload) - {'text', 'delivery_preset'}:
            raise StudioError('A voice audition accepts only exact sample text and delivery preset.')
        text = _text(payload.get('text'), 'Audition text', MAX_AUDITION_TEXT)
        delivery = normalize_delivery_preset(payload.get('delivery_preset') or 'neutral')
        if delivery in OWNER_REJECTED_DELIVERY_PRESETS:
            raise StudioError('That delivery preset needs repair. Try neutral for this audition.')
        if not self.lock.acquire(blocking=False):
            raise StudioError('A voice audition is already running. Please wait for its result.')
        try:
            self.active = True
            project = self.store.project(project_id)
            voice = next((item for item in project.get('studio_voices', []) if item.get('voice_id') == voice_id), None)
            if voice is None:
                raise StudioError('That voice is not saved in this project.')
            runtime = self.runtime()
            if not runtime.get('available'):
                raise StudioError(runtime.get('message') or 'The local voice engine is unavailable.')
            runtime_root = (self.store.state_dir / voice['catalog_relative']).resolve()
            if not runtime_root.is_relative_to(self.store.state_dir.resolve()):
                raise StudioError('Voice design storage is outside this Studio project store.')
            catalog_path = runtime_root / 'Voice/profiles/stable_original_voice_profiles_v1.json'
            if file_sha256(catalog_path) != voice['catalog_sha256']:
                raise StudioError('The saved voice description changed. Create a new voice design.')
            attempt_id = 'audition-' + uuid.uuid4().hex[:12]
            attempt = {'attempt_id': attempt_id, 'status': 'generating', 'text': text,
                'text_sha256': hashlib.sha256(text.encode()).hexdigest(), 'description_sha256': hashlib.sha256(voice['description'].encode()).hexdigest(),
                'catalog_sha256': voice['catalog_sha256'], 'seed': voice['seed'], 'delivery_preset': delivery,
                'created_at': now(), 'project_id': project_id, 'voice_id': voice_id}
            voice['auditions'].append(attempt)
            self.store._save('studio_voice_audition_started')
            try:
                service = self.service_factory(self.build_root, self.store.state_dir,
                    runtime_root=runtime_root, python_executable=runtime['python'],
                    model_path=Path(runtime['model']), model_inventory_path=Path(runtime['inventory']),
                    environment={**self.environment, 'KIRA_ORIGINAL_VOICE_PACKAGE_PATHS': json.dumps(runtime.get('package_paths', []))})
                result = service.generate(text, profile_id=voice['profile_id'], seed=voice['seed'],
                    delivery_preset=delivery, character_id=voice_id, attempt_id=attempt_id)
                path = Path(result['audio_path']).resolve()
                if not path.is_relative_to(self.store.state_dir.resolve()) or not path.is_file():
                    raise StudioError('Voice output did not remain inside Studio storage.')
                digest = file_sha256(path)
                for key, expected in {'audio_sha256': digest, 'text_sha256': attempt['text_sha256'],
                    'profile_id': voice['profile_id'], 'seed': voice['seed'], 'character_id': voice_id,
                    'attempt_id': attempt_id, 'delivery_preset': delivery}.items():
                    if result.get(key) != expected:
                        raise StudioError('Voice output did not match the exact audition request: ' + key)
                relative = path.relative_to(self.store.state_dir.resolve()).as_posix()
                asset = self.store.add_asset_for_project(project_id, {
                    'kind': 'audio', 'source': 'local_original_voice_private_preview',
                    'filename': voice['name'] + ' - ' + attempt_id + '.wav', 'local_path': str(path),
                    'url': '/media/' + relative, 'sha256': digest, 'synthetic': True, 'approved': False,
                    'studio_voice_id': voice_id, 'voice_profile_id': voice['profile_id'],
                    'persistent_seed': voice['seed'], 'delivery_preset': delivery,
                    'assignment_status': 'unassigned_private_preview', 'human_review_required': True,
                    'production_ready': False, 'long_form_ready': False, 'generation': result,
                    'text': text, 'duration_seconds': result.get('duration_seconds'),
                    'automatic_assignment_blocked': True, 'disclosure_required': True,
                })
                attempt.update(status='ready_to_listen', asset_id=asset['asset_id'], audio_sha256=digest,
                    duration_seconds=result.get('duration_seconds'), finished_at=now())
                self.store._save('studio_voice_audition_saved')
                return {'project_id': project_id, 'voice_id': voice_id, 'status': 'ready_to_listen',
                    'asset': asset, 'audition': deepcopy(attempt), 'message': 'Your original voice audition is ready to play.'}
            except Exception as exc:
                attempt.update(status='failed', error=str(exc)[-600:], finished_at=now())
                self.store._save('studio_voice_audition_failed')
                raise StudioError('Voice audition failed: ' + str(exc)[-600:]) from exc
        finally:
            self.active = False
            self.lock.release()
