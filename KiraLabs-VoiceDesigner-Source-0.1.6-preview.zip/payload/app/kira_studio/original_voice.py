"""Hash-bound, delivery-directed original voice generation for Video Studio.

This module owns the Studio contract around the separately installed Qwen
VoiceDesign runtime.  It deliberately does not import code from the runtime
root.  The only shared input is the immutable v1 profile catalog.  A caller
chooses a catalog profile, a persistent character seed, and one enumerated
delivery preset; arbitrary acting or identity instructions are never accepted.

The current VoiceDesign model has no independent speaker-identity channel.
Reusing the exact catalog profile and seed therefore provides best-effort
speaker continuity, not a guarantee of identical speaker identity.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
import wave
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Mapping


JOB_KIND = "videostudio_original_voice_job_v1"
RECEIPT_KIND = "videostudio_original_voice_receipt_v2"
MODEL_INVENTORY_SCHEMA = "kira.qwen3.profile-audition-evidence-package.v1"
CATALOG_ID = "stable_original_voice_profiles_v1"
CONTINUITY_LABEL = "best_effort_speaker_continuity"
ENGINE_NAME = "Qwen3-TTS-12Hz-1.7B-VoiceDesign"
CATALOG_RELATIVE = Path("Voice") / "profiles" / "stable_original_voice_profiles_v1.json"
MODEL_RELATIVE = Path("Voice") / "models" / "qwen3_tts" / ENGINE_NAME
RUNTIME_PYTHON_WINDOWS_RELATIVE = (
    Path("Voice")
    / "sidecars"
    / "qwen3_tts_voice_design_runtime"
    / ".venv"
    / "Scripts"
    / "python.exe"
)
RUNTIME_PYTHON_POSIX_RELATIVE = (
    Path("Voice")
    / "sidecars"
    / "qwen3_tts_voice_design_runtime"
    / ".venv"
    / "bin"
    / "python"
)

MAX_TEXT_CHARACTERS = 4_000
MAX_PRESET_NAME_CHARACTERS = 32
MAX_DIRECTION_CHARACTERS = 180
IDENTIFIER_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
PRESET_INPUT_RE = re.compile(r"^[a-zA-Z][a-zA-Z _-]*$")


# These are complete delivery instructions, not user-editable fragments.  They
# may shape performance but must not ask the model to replace speaker identity.
DELIVERY_PRESETS: dict[str, str] = {
    "neutral": "Deliver this line naturally and evenly, with restrained expression.",
    "warm": "Deliver this line with gentle warmth and welcoming sincerity.",
    "joyful": "Deliver this line with bright, genuine joy and an easy smile.",
    "excited": "Deliver this line with lively excitement, quicker energy, and clear articulation.",
    "worried": "Deliver this line with contained concern and slight hesitation.",
    "sad": "Deliver this line with subdued sadness, slower pacing, and emotional restraint.",
    "angry": "Deliver this line with controlled anger, firm emphasis, and clear articulation; do not shout.",
    "urgent": "Deliver this line with focused urgency, brisk pacing, and clear emphasis.",
    "fearful": "Deliver this line with contained fear, careful breath, and intelligible articulation.",
    "amused": "Deliver this line with subtle amusement and a restrained smile.",
    "deadpan": "Deliver this line dryly and evenly, with minimal inflection.",
    "whisper": "Deliver this line as a gentle, intelligible near-whisper without changing the speaker identity.",
    "tender": "Deliver this line with quiet tenderness, soft pacing, and sincere care.",
}

# Owner listening results are evidence about the current runtime, not a model
# capability claim.  Unlisted presets remain available only to make private
# review candidates; they are not production-approved.
OWNER_ACCEPTED_DELIVERY_PRESETS = frozenset({"neutral"})
OWNER_REJECTED_DELIVERY_PRESETS = frozenset({"worried", "angry", "excited"})

# These sources are synthetic review outputs, not uploaded/authorized reference
# voices.  A generic asset ``approved`` flag must never be enough to promote a
# rejected or still-pending performance into a production selection.
GENERATED_VOICE_REVIEW_SOURCES = frozenset(
    {
        "local_original_voice_private_preview",
        "local_emotion_voice_private_candidate",
        "emotion_voice_candidate_private_preview",
    }
)
EMOTION_CANDIDATE_LANE_PRESETS: dict[str, tuple[str, ...]] = {
    "worried_revision": ("worried",),
    "excited_revision": ("excited",),
    "neutral_to_angry": ("neutral", "angry"),
    "neutral_to_excited": ("neutral", "excited"),
}
MIXED_EMOTION_CANDIDATE_LANES = frozenset(
    {"neutral_to_angry", "neutral_to_excited"}
)

if any(len(direction) > MAX_DIRECTION_CHARACTERS for direction in DELIVERY_PRESETS.values()):
    raise RuntimeError("An original-voice delivery preset exceeds its safety boundary.")


RUNTIME_CONTRACT: dict[str, Any] = {
    "engine": ENGINE_NAME,
    "operation": "generate_voice_design",
    "language": "English",
    "local_model_files_only": True,
    "network_allowed": False,
    "reference_audio_allowed": False,
    "speaker_embedding_allowed": False,
    "donor_voice_allowed": False,
    "voice_cloning_allowed": False,
    "named_real_person_imitation_allowed": False,
    "existing_character_imitation_allowed": False,
    "identity_claim_allowed": False,
    "playback_allowed": False,
    "automatic_assignment_allowed": False,
    "activation_allowed": False,
    "publication_allowed": False,
}

CONTINUITY_CONTRACT: dict[str, Any] = {
    "label": CONTINUITY_LABEL,
    "profile_and_seed_reuse_required": True,
    "speaker_identity_guaranteed": False,
}

PROFILE_FIELDS = (
    "profile_id",
    "label",
    "voice_presentation",
    "register",
    "cadence",
    "style_instruction",
    "traits",
)


class OriginalVoiceError(ValueError):
    """Raised when the original-voice safety or provenance contract fails."""


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def file_artifact(path: Path) -> dict[str, Any]:
    """Return a path/size/hash record whose bytes can be revalidated later."""

    resolved = Path(path).expanduser().resolve()
    if not resolved.is_file():
        raise OriginalVoiceError("provenance_artifact_missing")
    return {
        "path": str(resolved),
        "size_bytes": resolved.stat().st_size,
        "sha256": file_sha256(resolved),
    }


def _validate_file_artifact(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise OriginalVoiceError(f"{label}_invalid")
    _exact_keys(value, {"path", "size_bytes", "sha256"}, label)
    path_value = value.get("path")
    size_value = value.get("size_bytes")
    digest = value.get("sha256")
    if not isinstance(path_value, str) or not path_value:
        raise OriginalVoiceError(f"{label}_path_invalid")
    if not isinstance(size_value, int) or isinstance(size_value, bool) or size_value < 0:
        raise OriginalVoiceError(f"{label}_size_invalid")
    if not isinstance(digest, str) or SHA256_RE.fullmatch(digest) is None:
        raise OriginalVoiceError(f"{label}_sha256_invalid")
    expected = file_artifact(Path(path_value))
    if dict(value) != expected:
        raise OriginalVoiceError(f"{label}_binding_mismatch")
    return expected


def load_model_inventory_reference(
    model_path: Path,
    inventory_path: Path,
) -> dict[str, Any]:
    """Bind a model directory to a pre-existing per-file hash inventory.

    Generation deliberately verifies the manifest bytes plus every listed file's
    path and size.  It does not pretend that hashing multi-gigabyte weights on
    every line occurred; the receipt says so explicitly while preserving the
    exact per-file SHA-256 inventory reference for an independent full audit.
    """

    model_root = Path(model_path).expanduser().resolve()
    inventory = Path(inventory_path).expanduser().resolve()
    if not model_root.is_dir():
        raise OriginalVoiceError("model_inventory_model_path_missing")
    try:
        raw = inventory.read_bytes()
        payload = json.loads(raw.decode("utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise OriginalVoiceError("model_inventory_unreadable") from exc
    if not isinstance(payload, Mapping) or payload.get("schema") != MODEL_INVENTORY_SCHEMA:
        raise OriginalVoiceError("model_inventory_schema_invalid")
    manifest = payload.get("model_manifest")
    if not isinstance(manifest, Mapping):
        raise OriginalVoiceError("model_inventory_manifest_missing")
    revision = manifest.get("revision")
    files = manifest.get("files")
    if not isinstance(revision, str) or not revision.strip() or len(revision) > 160:
        raise OriginalVoiceError("model_inventory_revision_invalid")
    if not isinstance(files, list) or not files or manifest.get("file_count") != len(files):
        raise OriginalVoiceError("model_inventory_files_invalid")

    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    total_bytes = 0
    for raw_item in files:
        if not isinstance(raw_item, Mapping):
            raise OriginalVoiceError("model_inventory_file_invalid")
        path_value = raw_item.get("path")
        size_value = raw_item.get("bytes")
        digest = raw_item.get("sha256")
        if (
            not isinstance(path_value, str)
            or not path_value
            or Path(path_value).is_absolute()
            or ".." in Path(path_value).parts
            or path_value in seen
        ):
            raise OriginalVoiceError("model_inventory_file_path_invalid")
        if not isinstance(size_value, int) or isinstance(size_value, bool) or size_value < 0:
            raise OriginalVoiceError("model_inventory_file_size_invalid")
        if not isinstance(digest, str) or SHA256_RE.fullmatch(digest) is None:
            raise OriginalVoiceError("model_inventory_file_sha256_invalid")
        source = model_root.joinpath(*Path(path_value).parts).resolve()
        try:
            source.relative_to(model_root)
        except ValueError as exc:
            raise OriginalVoiceError("model_inventory_file_escaped_model_root") from exc
        if not source.is_file() or source.stat().st_size != size_value:
            raise OriginalVoiceError("model_inventory_file_presence_or_size_mismatch")
        normalized.append(
            {"path": path_value, "size_bytes": size_value, "sha256": digest}
        )
        seen.add(path_value)
        total_bytes += size_value
    normalized.sort(key=lambda item: item["path"])
    tree_payload = {"revision": revision, "files": normalized}
    return {
        "model_path": str(model_root),
        "inventory_path": str(inventory),
        "inventory_schema": MODEL_INVENTORY_SCHEMA,
        "inventory_sha256": hashlib.sha256(raw).hexdigest(),
        "inventory_size_bytes": len(raw),
        "revision": revision,
        "tree_sha256": canonical_sha256(tree_payload),
        "file_count": len(normalized),
        "total_bytes": total_bytes,
        "listed_file_hashes_present": True,
        "listed_file_presence_and_size_verified_before_execution": True,
        "all_model_file_hashes_recomputed_before_execution": False,
    }


def normalize_delivery_preset(value: str) -> str:
    """Normalize a short preset name and reject all free-form direction text."""

    if not isinstance(value, str):
        raise OriginalVoiceError("delivery_preset_must_be_a_string")
    if not value or len(value) > MAX_PRESET_NAME_CHARACTERS:
        raise OriginalVoiceError("delivery_preset_length_invalid")
    if any(ord(character) < 32 or ord(character) == 127 for character in value):
        raise OriginalVoiceError("delivery_preset_contains_control_characters")
    trimmed = value.strip()
    if not trimmed or PRESET_INPUT_RE.fullmatch(trimmed) is None:
        raise OriginalVoiceError("delivery_preset_contains_unsupported_characters")
    normalized = re.sub(r"[ _-]+", "_", trimmed.casefold())
    if normalized not in DELIVERY_PRESETS:
        raise OriginalVoiceError("delivery_preset_not_supported")
    return normalized


def delivery_preset_owner_review_status(value: str) -> str:
    preset = normalize_delivery_preset(value)
    if preset in OWNER_ACCEPTED_DELIVERY_PRESETS:
        return "accepted"
    if preset in OWNER_REJECTED_DELIVERY_PRESETS:
        return "rejected"
    return "pending_owner_review"


def generated_voice_production_blockers(asset: Mapping[str, Any]) -> tuple[str, ...]:
    """Return fail-closed production blockers for a generated voice asset.

    The normal asset-review button records that a person looked at an asset; it
    is not evidence that a rejected/pending delivery preset became acceptable.
    Emotion revision candidates additionally require a hash-bound owner gate,
    and a mixed-emotion take requires an explicit transition-naturalness gate.
    No current candidate has those gates, so worried v10 remains pending owner
    listening even though its automated checks passed.
    """

    if not isinstance(asset, Mapping):
        return ("generated_voice_asset_invalid",)
    generation_value = asset.get("generation")
    generation = generation_value if isinstance(generation_value, Mapping) else {}
    source = str(asset.get("source") or "").strip().casefold()
    lane = str(
        asset.get("emotion_candidate_lane")
        or asset.get("candidate_lane")
        or generation.get("emotion_candidate_lane")
        or generation.get("candidate_lane")
        or generation.get("lane")
        or ""
    ).strip().casefold()
    guarded = source in GENERATED_VOICE_REVIEW_SOURCES or lane in EMOTION_CANDIDATE_LANE_PRESETS
    if not guarded:
        return ()

    presets: list[str] = []
    for container in (asset, generation):
        single = container.get("delivery_preset")
        if isinstance(single, str) and single.strip():
            presets.append(single)
        multiple = container.get("delivery_presets")
        if isinstance(multiple, (list, tuple)):
            presets.extend(item for item in multiple if isinstance(item, str) and item.strip())
    presets.extend(EMOTION_CANDIDATE_LANE_PRESETS.get(lane, ()))

    blockers: list[str] = []
    canonical_presets: list[str] = []
    for value in presets:
        try:
            canonical = normalize_delivery_preset(value)
        except OriginalVoiceError:
            blockers.append("generated_voice_delivery_preset_invalid")
            continue
        if canonical not in canonical_presets:
            canonical_presets.append(canonical)
    if not canonical_presets:
        blockers.append("generated_voice_delivery_preset_missing")
    for preset in canonical_presets:
        verdict = delivery_preset_owner_review_status(preset)
        if verdict != "accepted":
            blockers.append(
                f"voice_preset_not_owner_accepted:{preset}:{verdict}"
            )

    recorded_verdict = asset.get("performance_preset_owner_review")
    if recorded_verdict is not None and len(canonical_presets) == 1:
        current_verdict = delivery_preset_owner_review_status(canonical_presets[0])
        if recorded_verdict != current_verdict:
            blockers.append("voice_preset_owner_review_truth_changed")

    if lane in EMOTION_CANDIDATE_LANE_PRESETS:
        owner_gate_value = asset.get("emotion_candidate_owner_gate")
        owner_gate = owner_gate_value if isinstance(owner_gate_value, Mapping) else {}
        asset_sha256 = str(asset.get("sha256") or "").casefold()
        gate_sha256 = str(owner_gate.get("audio_sha256") or "").casefold()
        candidate_gate_accepted = (
            owner_gate.get("candidate_accepted") is True
            and owner_gate.get("emotional_naturalness") == "accepted"
            and owner_gate.get("voice_cast_match") == "accepted"
            and SHA256_RE.fullmatch(asset_sha256) is not None
            and gate_sha256 == asset_sha256
        )
        if not candidate_gate_accepted:
            blockers.append("emotion_candidate_owner_acceptance_missing")
        if lane in MIXED_EMOTION_CANDIDATE_LANES and (
            not candidate_gate_accepted
            or owner_gate.get("transition_naturalness") != "accepted"
        ):
            blockers.append("mixed_emotion_transition_owner_gate_missing")

    return tuple(dict.fromkeys(blockers))


def _identifier(value: Any, label: str) -> str:
    if not isinstance(value, str) or IDENTIFIER_RE.fullmatch(value) is None:
        raise OriginalVoiceError(f"{label}_invalid")
    return value


def _text(value: Any) -> str:
    if not isinstance(value, str):
        raise OriginalVoiceError("text_must_be_a_string")
    result = value.strip()
    if not result:
        raise OriginalVoiceError("text_must_not_be_empty")
    if len(result) > MAX_TEXT_CHARACTERS:
        raise OriginalVoiceError("text_exceeds_4000_characters")
    if any(ord(character) < 32 and character not in "\n\r\t" for character in result):
        raise OriginalVoiceError("text_contains_control_characters")
    return result


def _catalog_path(runtime_root: Path) -> Path:
    return Path(runtime_root).expanduser().resolve().joinpath(*CATALOG_RELATIVE.parts)


def _validate_profile(profile: Mapping[str, Any]) -> None:
    for field in PROFILE_FIELDS:
        if field not in profile:
            raise OriginalVoiceError("stable_profile_fields_missing")
    _identifier(profile.get("profile_id"), "profile_id")
    for field in ("label", "voice_presentation", "register", "cadence", "style_instruction"):
        value = profile.get(field)
        if not isinstance(value, str) or not value.strip():
            raise OriginalVoiceError("stable_profile_fields_invalid")
    style = profile["style_instruction"]
    if len(style) > 1_000 or style != style.strip():
        raise OriginalVoiceError("stable_profile_style_instruction_invalid")
    traits = profile.get("traits")
    if not isinstance(traits, list) or not traits or not all(
        isinstance(item, str) and item.strip() for item in traits
    ):
        raise OriginalVoiceError("stable_profile_traits_invalid")
    constraints = profile.get("identity_constraints")
    if not isinstance(constraints, Mapping) or constraints.get("original_text_style_only") is not True:
        raise OriginalVoiceError("stable_profile_is_not_original_text_style_only")
    for key in (
        "reference_audio_allowed",
        "speaker_embedding_allowed",
        "donor_voice_allowed",
        "voice_cloning_allowed",
        "named_real_person_imitation_allowed",
        "existing_character_imitation_allowed",
        "real_person_or_character_identity_claim_allowed",
    ):
        if constraints.get(key) is not False:
            raise OriginalVoiceError("stable_profile_identity_boundary_is_not_closed")


def load_profile_catalog(runtime_root: Path) -> tuple[dict[str, Any], str]:
    """Load and validate the immutable v1 profile catalog from a runtime root."""

    path = _catalog_path(runtime_root)
    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise OriginalVoiceError("stable_profile_catalog_unreadable") from exc
    if not raw or len(raw) > 1024 * 1024:
        raise OriginalVoiceError("stable_profile_catalog_size_invalid")
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise OriginalVoiceError("stable_profile_catalog_invalid_json") from exc
    if not isinstance(value, dict):
        raise OriginalVoiceError("stable_profile_catalog_invalid")
    if (
        value.get("schema_version") != 1
        or value.get("catalog_id") != CATALOG_ID
        or value.get("record_type") != "STABLE_ORIGINAL_NONIMITATION_VOICE_PROFILE_CATALOG"
        or value.get("state") != "STATIC_STYLE_DESIGNS_ONLY_UNSYNTHESIZED"
    ):
        raise OriginalVoiceError("stable_profile_catalog_identity_invalid")
    profiles = value.get("profiles")
    if not isinstance(profiles, list) or not profiles:
        raise OriginalVoiceError("stable_profile_catalog_profiles_invalid")
    identifiers: list[str] = []
    for profile in profiles:
        if not isinstance(profile, Mapping):
            raise OriginalVoiceError("stable_profile_catalog_profiles_invalid")
        _validate_profile(profile)
        identifiers.append(str(profile["profile_id"]))
    if len(identifiers) != len(set(identifiers)):
        raise OriginalVoiceError("stable_profile_catalog_duplicate_profile")
    return value, hashlib.sha256(raw).hexdigest()


def _catalog_profile(catalog: Mapping[str, Any], profile_id: str) -> dict[str, Any]:
    matches = [
        dict(item)
        for item in catalog.get("profiles", [])
        if isinstance(item, Mapping) and item.get("profile_id") == profile_id
    ]
    if len(matches) != 1:
        raise OriginalVoiceError("stable_profile_not_found")
    return matches[0]


def build_synthesis_instruction(base_style: str, direction: str) -> str:
    """Append bounded delivery to the exact catalog style; never replace it."""

    if not isinstance(base_style, str) or not base_style or base_style != base_style.strip():
        raise OriginalVoiceError("base_style_instruction_invalid")
    if direction not in DELIVERY_PRESETS.values():
        raise OriginalVoiceError("delivery_direction_is_not_a_catalogued_preset")
    return (
        f"{base_style} Preserve the same original speaker identity, timbre, register, "
        "accent, and age described by that base profile. For this line only: "
        f"{direction} Do not imitate or claim to be any real person or existing character."
    )


def compute_identity_binding_sha256(profile_id: str, base_style: str, seed: int) -> str:
    if not isinstance(seed, int) or isinstance(seed, bool) or not 0 <= seed <= 2**63 - 1:
        raise OriginalVoiceError("seed_must_be_a_nonnegative_int64")
    return canonical_sha256(
        {
            "profile_id": _identifier(profile_id, "profile_id"),
            "base_style_instruction": base_style,
            "seed": seed,
        }
    )


def build_voice_job(
    text: str,
    *,
    runtime_root: Path,
    profile_id: str,
    seed: int,
    delivery_preset: str = "neutral",
    character_id: str,
    attempt_id: str,
) -> dict[str, Any]:
    """Create one immutable, delivery-directed, private voice-generation job."""

    character_id = _identifier(character_id, "character_id")
    attempt_id = _identifier(attempt_id, "attempt_id")
    profile_id = _identifier(profile_id, "profile_id")
    if not isinstance(seed, int) or isinstance(seed, bool) or not 0 <= seed <= 2**63 - 1:
        raise OriginalVoiceError("seed_must_be_a_nonnegative_int64")
    text = _text(text)
    preset = normalize_delivery_preset(delivery_preset)
    direction = DELIVERY_PRESETS[preset]
    catalog, catalog_sha256 = load_profile_catalog(runtime_root)
    catalog_profile = _catalog_profile(catalog, profile_id)
    profile = {field: catalog_profile[field] for field in PROFILE_FIELDS}
    base_style = profile["style_instruction"]
    identity_binding = compute_identity_binding_sha256(profile_id, base_style, seed)
    synthesis_instruction = build_synthesis_instruction(base_style, direction)
    job: dict[str, Any] = {
        "schema_version": 1,
        "record_kind": JOB_KIND,
        "character_id": character_id,
        "attempt_id": attempt_id,
        "text": text,
        "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "seed": seed,
        "catalog": {
            "catalog_id": CATALOG_ID,
            "catalog_sha256": catalog_sha256,
        },
        "profile": profile,
        "performance": {
            "preset": preset,
            "direction": direction,
            "direction_sha256": hashlib.sha256(direction.encode("utf-8")).hexdigest(),
            "scope": "delivery_only",
        },
        "identity_binding_sha256": identity_binding,
        "continuity_contract": dict(CONTINUITY_CONTRACT),
        "synthesis_instruction": synthesis_instruction,
        "runtime_contract": dict(RUNTIME_CONTRACT),
        "status": "ready_for_explicit_local_generation",
    }
    job["job_sha256"] = canonical_sha256(job)
    return job


def _exact_keys(value: Mapping[str, Any], expected: set[str], label: str) -> None:
    if set(value) != expected:
        raise OriginalVoiceError(f"{label}_fields_invalid")


def validate_voice_job(job: Mapping[str, Any], *, runtime_root: Path) -> dict[str, Any]:
    """Revalidate a complete job against the current immutable catalog."""

    if not isinstance(job, Mapping):
        raise OriginalVoiceError("job_must_be_an_object")
    if job.get("record_kind") != JOB_KIND or job.get("schema_version") != 1:
        raise OriginalVoiceError("job_kind_or_version_invalid")
    supplied_hash = job.get("job_sha256")
    if not isinstance(supplied_hash, str) or SHA256_RE.fullmatch(supplied_hash) is None:
        raise OriginalVoiceError("job_sha256_invalid")
    unsigned = dict(job)
    unsigned.pop("job_sha256", None)
    if canonical_sha256(unsigned) != supplied_hash:
        raise OriginalVoiceError("job_sha256_mismatch")
    _exact_keys(
        job,
        {
            "schema_version",
            "record_kind",
            "character_id",
            "attempt_id",
            "text",
            "text_sha256",
            "seed",
            "catalog",
            "profile",
            "performance",
            "identity_binding_sha256",
            "continuity_contract",
            "synthesis_instruction",
            "runtime_contract",
            "status",
            "job_sha256",
        },
        "job",
    )
    if job.get("status") != "ready_for_explicit_local_generation":
        raise OriginalVoiceError("job_status_invalid")
    _identifier(job.get("character_id"), "character_id")
    _identifier(job.get("attempt_id"), "attempt_id")
    seed = job.get("seed")
    if not isinstance(seed, int) or isinstance(seed, bool) or not 0 <= seed <= 2**63 - 1:
        raise OriginalVoiceError("seed_must_be_a_nonnegative_int64")
    text = _text(job.get("text"))
    if hashlib.sha256(text.encode("utf-8")).hexdigest() != job.get("text_sha256"):
        raise OriginalVoiceError("text_sha256_mismatch")

    catalog_value, catalog_sha256 = load_profile_catalog(runtime_root)
    catalog_record = job.get("catalog")
    if not isinstance(catalog_record, Mapping):
        raise OriginalVoiceError("catalog_record_missing")
    if dict(catalog_record) != {"catalog_id": CATALOG_ID, "catalog_sha256": catalog_sha256}:
        raise OriginalVoiceError("catalog_record_mismatch")

    profile = job.get("profile")
    if not isinstance(profile, Mapping):
        raise OriginalVoiceError("profile_missing")
    _exact_keys(profile, set(PROFILE_FIELDS), "profile")
    profile_id = _identifier(profile.get("profile_id"), "profile_id")
    catalog_profile = _catalog_profile(catalog_value, profile_id)
    expected_profile = {field: catalog_profile[field] for field in PROFILE_FIELDS}
    if dict(profile) != expected_profile:
        raise OriginalVoiceError("profile_does_not_match_catalog")

    performance = job.get("performance")
    if not isinstance(performance, Mapping):
        raise OriginalVoiceError("performance_missing")
    _exact_keys(performance, {"preset", "direction", "direction_sha256", "scope"}, "performance")
    preset = normalize_delivery_preset(performance.get("preset"))
    direction = DELIVERY_PRESETS[preset]
    if performance.get("direction") != direction or performance.get("scope") != "delivery_only":
        raise OriginalVoiceError("performance_direction_mismatch")
    direction_sha256 = hashlib.sha256(direction.encode("utf-8")).hexdigest()
    if performance.get("direction_sha256") != direction_sha256:
        raise OriginalVoiceError("performance_direction_sha256_mismatch")

    base_style = expected_profile["style_instruction"]
    identity_binding = compute_identity_binding_sha256(profile_id, base_style, seed)
    if job.get("identity_binding_sha256") != identity_binding:
        raise OriginalVoiceError("identity_binding_sha256_mismatch")
    if dict(job.get("continuity_contract") or {}) != CONTINUITY_CONTRACT:
        raise OriginalVoiceError("continuity_contract_mismatch")
    expected_instruction = build_synthesis_instruction(base_style, direction)
    if job.get("synthesis_instruction") != expected_instruction:
        raise OriginalVoiceError("synthesis_instruction_mismatch")
    if not expected_instruction.startswith(base_style):
        raise OriginalVoiceError("base_style_instruction_was_not_preserved")
    if dict(job.get("runtime_contract") or {}) != RUNTIME_CONTRACT:
        raise OriginalVoiceError("runtime_boundary_not_closed")
    return json.loads(canonical_json_bytes(job).decode("utf-8"))


def _write_exclusive(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as target:
        target.write(data)
        target.write(b"\n")
        target.flush()
        os.fsync(target.fileno())


def _load_json_object(path: Path, error_code: str) -> dict[str, Any]:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise OriginalVoiceError(error_code) from exc
    if not isinstance(value, dict):
        raise OriginalVoiceError(error_code)
    return value


def _parse_utc_timestamp(value: Any, label: str) -> datetime:
    if not isinstance(value, str) or not value.endswith("Z"):
        raise OriginalVoiceError(f"runtime_receipt_{label}_invalid")
    try:
        parsed = datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError as exc:
        raise OriginalVoiceError(f"runtime_receipt_{label}_invalid") from exc
    if parsed.utcoffset() is None or parsed.utcoffset().total_seconds() != 0:
        raise OriginalVoiceError(f"runtime_receipt_{label}_invalid")
    return parsed


def _validate_model_binding(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise OriginalVoiceError("runtime_receipt_model_binding_invalid")
    _exact_keys(
        value,
        {
            "model_path",
            "inventory_path",
            "inventory_schema",
            "inventory_sha256",
            "inventory_size_bytes",
            "revision",
            "tree_sha256",
            "file_count",
            "total_bytes",
            "listed_file_hashes_present",
            "listed_file_presence_and_size_verified_before_execution",
            "all_model_file_hashes_recomputed_before_execution",
        },
        "runtime_receipt_model_binding",
    )
    model_path = value.get("model_path")
    inventory_path = value.get("inventory_path")
    if not isinstance(model_path, str) or not isinstance(inventory_path, str):
        raise OriginalVoiceError("runtime_receipt_model_binding_paths_invalid")
    observed = load_model_inventory_reference(Path(model_path), Path(inventory_path))
    if dict(value) != observed:
        raise OriginalVoiceError("runtime_receipt_model_binding_mismatch")
    return observed


def _validate_execution_provenance(
    receipt: Mapping[str, Any],
    *,
    output_dir: Path,
    job: Mapping[str, Any],
) -> None:
    job_id = f"voice-{job['job_sha256'][:20]}"
    if receipt.get("job_id") != job_id:
        raise OriginalVoiceError("runtime_receipt_job_id_mismatch")
    if receipt.get("canonical_request_sha256") != job["job_sha256"]:
        raise OriginalVoiceError("runtime_receipt_canonical_request_sha256_mismatch")
    exact_request = receipt.get("exact_request")
    if not isinstance(exact_request, Mapping) or exact_request != {
        "text": job["text"],
        "text_sha256": job["text_sha256"],
        "synthesis_instruction": job["synthesis_instruction"],
        "synthesis_instruction_sha256": hashlib.sha256(
            job["synthesis_instruction"].encode("utf-8")
        ).hexdigest(),
        "delivery_direction": job["performance"]["direction"],
        "delivery_direction_sha256": job["performance"]["direction_sha256"],
        "seed": job["seed"],
    }:
        raise OriginalVoiceError("runtime_receipt_exact_request_mismatch")

    request_artifact = _validate_file_artifact(
        receipt.get("request_artifact"), "runtime_receipt_request_artifact"
    )
    if request_artifact["sha256"] != receipt.get("job_file_sha256"):
        raise OriginalVoiceError("runtime_receipt_job_file_sha256_mismatch")
    persisted_request = _load_json_object(
        Path(request_artifact["path"]), "runtime_receipt_request_artifact_unreadable"
    )
    if persisted_request.get("job_sha256") != job["job_sha256"]:
        raise OriginalVoiceError("runtime_receipt_request_artifact_job_mismatch")

    generator = receipt.get("generator")
    if not isinstance(generator, Mapping):
        raise OriginalVoiceError("runtime_receipt_generator_invalid")
    _exact_keys(generator, {"worker_script", "studio_module"}, "runtime_receipt_generator")
    worker = _validate_file_artifact(
        generator.get("worker_script"), "runtime_receipt_worker_script"
    )
    studio_module = _validate_file_artifact(
        generator.get("studio_module"), "runtime_receipt_studio_module"
    )

    runtime = receipt.get("runtime")
    if not isinstance(runtime, Mapping):
        raise OriginalVoiceError("runtime_receipt_runtime_invalid")
    _exact_keys(runtime, {"executable", "backend"}, "runtime_receipt_runtime")
    executable = _validate_file_artifact(
        runtime.get("executable"), "runtime_receipt_executable"
    )
    backend = runtime.get("backend")
    if not isinstance(backend, Mapping):
        raise OriginalVoiceError("runtime_receipt_backend_invalid")
    _exact_keys(
        backend,
        {
            "module",
            "class",
            "method",
            "qwen_tts_version",
            "torch_version",
            "cuda_runtime_version",
        },
        "runtime_receipt_backend",
    )
    if (
        backend.get("module") != "qwen_tts"
        or backend.get("class") != "Qwen3TTSModel"
        or backend.get("method") != "generate_voice_design"
        or not all(
            isinstance(backend.get(key), str) and backend.get(key)
            for key in ("qwen_tts_version", "torch_version", "cuda_runtime_version")
        )
    ):
        raise OriginalVoiceError("runtime_receipt_backend_mismatch")

    model_binding = _validate_model_binding(receipt.get("model_binding"))
    execution = receipt.get("execution")
    if not isinstance(execution, Mapping):
        raise OriginalVoiceError("runtime_receipt_execution_invalid")
    _exact_keys(
        execution,
        {
            "worker_run_id",
            "started_at_utc",
            "ended_at_utc",
            "exact_command",
            "paths",
            "settings",
            "device",
            "model_load_completed",
            "generation_completed",
        },
        "runtime_receipt_execution",
    )
    run_id = execution.get("worker_run_id")
    if not isinstance(run_id, str):
        raise OriginalVoiceError("runtime_receipt_worker_run_id_invalid")
    try:
        if str(uuid.UUID(run_id)) != run_id:
            raise ValueError
    except ValueError as exc:
        raise OriginalVoiceError("runtime_receipt_worker_run_id_invalid") from exc
    started = _parse_utc_timestamp(execution.get("started_at_utc"), "started_at_utc")
    ended = _parse_utc_timestamp(execution.get("ended_at_utc"), "ended_at_utc")
    if ended < started:
        raise OriginalVoiceError("runtime_receipt_worker_timestamps_invalid")
    paths = execution.get("paths")
    if not isinstance(paths, Mapping):
        raise OriginalVoiceError("runtime_receipt_execution_paths_invalid")
    _exact_keys(
        paths,
        {"build_root", "runtime_root", "job_path", "output_dir", "model_path", "model_inventory_path", "cache_root"},
        "runtime_receipt_execution_paths",
    )
    for key, value in paths.items():
        if not isinstance(value, str) or not Path(value).is_absolute():
            raise OriginalVoiceError(f"runtime_receipt_execution_path_{key}_invalid")
    if Path(paths["job_path"]).resolve() != Path(request_artifact["path"]).resolve():
        raise OriginalVoiceError("runtime_receipt_execution_job_path_mismatch")
    if Path(paths["output_dir"]).resolve() != output_dir:
        raise OriginalVoiceError("runtime_receipt_execution_output_dir_mismatch")
    if Path(paths["model_path"]).resolve() != Path(model_binding["model_path"]).resolve():
        raise OriginalVoiceError("runtime_receipt_execution_model_path_mismatch")
    if Path(paths["model_inventory_path"]).resolve() != Path(model_binding["inventory_path"]).resolve():
        raise OriginalVoiceError("runtime_receipt_execution_model_inventory_path_mismatch")
    settings = execution.get("settings")
    expected_settings = {
        "operation": "generate_voice_design",
        "language": job["runtime_contract"]["language"],
        "seed": job["seed"],
        "device_map": "cuda:0",
        "dtype": "torch.bfloat16",
        "attention_implementation": "sdpa",
        "local_files_only": True,
        "candidate_count": 1,
    }
    if settings != expected_settings:
        raise OriginalVoiceError("runtime_receipt_execution_settings_mismatch")
    device = execution.get("device")
    if (
        not isinstance(device, Mapping)
        or device.get("requested") != "cuda:0"
        or not isinstance(device.get("resolved_name"), str)
        or not device.get("resolved_name")
    ):
        raise OriginalVoiceError("runtime_receipt_execution_device_invalid")
    if execution.get("model_load_completed") is not True or execution.get("generation_completed") is not True:
        raise OriginalVoiceError("runtime_receipt_execution_completion_missing")

    expected_command = [
        executable["path"],
        "-B",
        worker["path"],
        "--build-root",
        paths["build_root"],
        "--runtime-root",
        paths["runtime_root"],
        "--job",
        paths["job_path"],
        "--job-file-sha256",
        request_artifact["sha256"],
        "--output-dir",
        paths["output_dir"],
        "--model-path",
        paths["model_path"],
        "--model-inventory",
        paths["model_inventory_path"],
        "--cache-root",
        paths["cache_root"],
    ]
    if execution.get("exact_command") != expected_command:
        raise OriginalVoiceError("runtime_receipt_exact_command_mismatch")
    try:
        if Path(studio_module["path"]).resolve() != Path(__file__).resolve():
            raise OriginalVoiceError("runtime_receipt_studio_module_path_mismatch")
    except OSError as exc:
        raise OriginalVoiceError("runtime_receipt_studio_module_path_mismatch") from exc


def validate_voice_output(output_dir: Path, job: Mapping[str, Any]) -> dict[str, Any]:
    """Validate an atomic worker output pair and return path-bearing receipt data."""

    output_dir = Path(output_dir).resolve()
    audio_path = output_dir / "voice.wav"
    receipt_path = output_dir / "runtime.receipt.json"
    if not audio_path.is_file() or not receipt_path.is_file():
        raise OriginalVoiceError("runtime_output_incomplete")
    receipt = _load_json_object(receipt_path, "runtime_receipt_unreadable")
    required = {
        "schema_version": 1,
        "record_kind": RECEIPT_KIND,
        "status": "generated_unreviewed_private_preview",
        "job_sha256": job["job_sha256"],
        "character_id": job["character_id"],
        "attempt_id": job["attempt_id"],
        "profile_id": job["profile"]["profile_id"],
        "text_sha256": job["text_sha256"],
        "seed": job["seed"],
        "delivery_preset": job["performance"]["preset"],
        "direction_sha256": job["performance"]["direction_sha256"],
        "identity_binding_sha256": job["identity_binding_sha256"],
        "speaker_continuity": CONTINUITY_LABEL,
        "speaker_identity_guaranteed": False,
        "model": ENGINE_NAME,
        "sample_rate_hz": 24_000,
        "offline_mode": True,
        "network_used": False,
        "reference_audio_used": False,
        "speaker_embedding_used": False,
        "voice_cloning_used": False,
        "named_imitation_used": False,
        "playback_performed": False,
        "automatic_assignment_performed": False,
        "activation_performed": False,
        "publication_performed": False,
    }
    for key, expected in required.items():
        if receipt.get(key) != expected:
            raise OriginalVoiceError(f"runtime_receipt_{key}_mismatch")
    _validate_execution_provenance(receipt, output_dir=output_dir, job=job)
    if receipt.get("audio_sha256") != file_sha256(audio_path):
        raise OriginalVoiceError("runtime_audio_sha256_mismatch")
    output_wav = receipt.get("output_wav")
    if not isinstance(output_wav, Mapping) or output_wav != {
        "path": str(audio_path),
        "relative_path": "voice.wav",
        "size_bytes": audio_path.stat().st_size,
        "sha256": file_sha256(audio_path),
    }:
        raise OriginalVoiceError("runtime_output_wav_binding_mismatch")
    try:
        with wave.open(str(audio_path), "rb") as wav_file:
            channels = wav_file.getnchannels()
            width = wav_file.getsampwidth()
            rate = wav_file.getframerate()
            frames = wav_file.getnframes()
            compression = wav_file.getcomptype()
    except (OSError, wave.Error) as exc:
        raise OriginalVoiceError("runtime_audio_unreadable") from exc
    duration = frames / float(rate or 1)
    if (
        channels != 1
        or width != 2
        or rate != 24_000
        or compression != "NONE"
        or not 0.25 <= duration <= 30.0
    ):
        raise OriginalVoiceError("runtime_audio_format_or_duration_invalid")
    if receipt.get("sample_count") != frames:
        raise OriginalVoiceError("runtime_receipt_sample_count_mismatch")
    recorded_duration = receipt.get("duration_seconds")
    if not isinstance(recorded_duration, (int, float)) or abs(float(recorded_duration) - duration) > 0.000001:
        raise OriginalVoiceError("runtime_receipt_duration_mismatch")
    result = dict(receipt)
    result.update(
        {
            "audio_path": str(audio_path),
            "receipt_path": str(receipt_path),
            "receipt_sha256": file_sha256(receipt_path),
        }
    )
    return result


WorkerRunner = Callable[[Path, Path, Path, Path, Path], None]


class OriginalVoiceService:
    """Synchronous service facade for later integration into ``services.py``."""

    PROVIDER = "local_qwen_original_voice_design_v1"

    def __init__(
        self,
        build_root: Path,
        state_dir: Path,
        *,
        runtime_root: Path | None = None,
        python_executable: str | Path | None = None,
        worker_path: Path | None = None,
        model_path: Path | None = None,
        model_inventory_path: Path | None = None,
        environment: Mapping[str, str] | None = None,
        runner: WorkerRunner | None = None,
    ):
        self.build_root = Path(build_root).expanduser().resolve()
        self.state_dir = Path(state_dir).expanduser().resolve()
        self.jobs_root = self.state_dir / "original_voice_jobs"
        config = dict(os.environ if environment is None else environment)
        configured_root = runtime_root or config.get("KIRA_ORIGINAL_VOICE_RUNTIME_ROOT")
        self.runtime_root = (
            Path(configured_root).expanduser().resolve() if configured_root else None
        )
        self.worker_path = Path(
            worker_path or self.build_root / "tools" / "isolated_original_voice_worker.py"
        ).expanduser().resolve()
        configured_model = model_path or config.get("KIRA_ORIGINAL_VOICE_MODEL_PATH")
        self.model_path = (
            Path(configured_model).expanduser().resolve()
            if configured_model
            else self.runtime_root.joinpath(*MODEL_RELATIVE.parts)
            if self.runtime_root
            else None
        )
        configured_inventory = model_inventory_path or config.get(
            "KIRA_ORIGINAL_VOICE_MODEL_INVENTORY"
        )
        self.model_inventory_path = (
            Path(configured_inventory).expanduser().resolve()
            if configured_inventory
            else None
        )
        configured_python = python_executable or config.get("KIRA_ORIGINAL_VOICE_PYTHON")
        if configured_python:
            self.python_executable = str(configured_python)
        elif self.runtime_root:
            relative = (
                RUNTIME_PYTHON_WINDOWS_RELATIVE
                if os.name == "nt"
                else RUNTIME_PYTHON_POSIX_RELATIVE
            )
            self.python_executable = str(self.runtime_root.joinpath(*relative.parts))
        else:
            self.python_executable = ""
        self._environment = config
        self._runner = runner

    def _resolved_python_executable(self) -> Path | None:
        if not self.python_executable:
            return None
        candidate = Path(self.python_executable).expanduser()
        if candidate.is_file():
            return candidate.resolve()
        located = shutil.which(self.python_executable)
        return Path(located).resolve() if located else None

    def _python_ready(self) -> bool:
        return self._resolved_python_executable() is not None

    def status(self) -> dict[str, Any]:
        catalog_ready = False
        profile_ids: list[str] = []
        catalog_error: str | None = None
        if self.runtime_root:
            try:
                catalog, _ = load_profile_catalog(self.runtime_root)
                profile_ids = [str(item["profile_id"]) for item in catalog["profiles"]]
                catalog_ready = True
            except OriginalVoiceError as exc:
                catalog_error = str(exc)
        runtime_ready = self._python_ready() and self.worker_path.is_file()
        model_ready = bool(self.model_path and self.model_path.is_dir())
        model_inventory_ready = False
        model_inventory_error: str | None = None
        if model_ready and self.model_inventory_path and self.model_path:
            try:
                load_model_inventory_reference(
                    self.model_path, self.model_inventory_path
                )
                model_inventory_ready = True
            except OriginalVoiceError as exc:
                model_inventory_error = str(exc)
        elif model_ready:
            model_inventory_error = "model_inventory_not_configured"
        available = (
            catalog_ready
            and runtime_ready
            and model_ready
            and model_inventory_ready
        )
        return {
            "provider": self.PROVIDER,
            "available": available,
            "catalog_ready": catalog_ready,
            "runtime_ready": runtime_ready,
            "model_ready": model_ready,
            "model_inventory_ready": model_inventory_ready,
            "profile_ids": profile_ids,
            "delivery_presets": list(DELIVERY_PRESETS),
            "performance_preset_owner_review": {
                "required": True,
                "accepted": sorted(OWNER_ACCEPTED_DELIVERY_PRESETS),
                "rejected": sorted(OWNER_REJECTED_DELIVERY_PRESETS),
                "pending": sorted(
                    set(DELIVERY_PRESETS)
                    - OWNER_ACCEPTED_DELIVERY_PRESETS
                    - OWNER_REJECTED_DELIVERY_PRESETS
                ),
            },
            "speaker_continuity": CONTINUITY_LABEL,
            "speaker_identity_guaranteed": False,
            "long_form_ready": False,
            "production_ready": False,
            "offline_weights_only": True,
            "network_allowed": False,
            "reference_audio_allowed": False,
            "speaker_embedding_allowed": False,
            "voice_cloning_allowed": False,
            "named_imitation_allowed": False,
            "human_review_required": True,
            "automatic_assignment_allowed": False,
            "activation_allowed": False,
            "publication_allowed": False,
            "process_isolated_per_generation": True,
            "gpu_probe_performed": False,
            "catalog_error": catalog_error,
            "model_inventory_error": model_inventory_error,
            "message": (
                "Ready only for explicit private original-voice previews; owner review is required and long-form use is not ready."
                if available
                else "Configure the original-voice runtime root, sidecar Python, existing local VoiceDesign model, and its hash-bound inventory."
            ),
        }

    def _default_runner(
        self,
        job_path: Path,
        output_dir: Path,
        runtime_root: Path,
        model_path: Path,
        cache_root: Path,
    ) -> None:
        assert self.model_inventory_path is not None
        executable = self._resolved_python_executable()
        if executable is None:
            raise OriginalVoiceError("original_voice_python_unavailable")
        child_environment = {
            key: value
            for key, value in self._environment.items()
            if key.upper()
            in {
                "APPDATA",
                "COMSPEC",
                "CUDA_PATH",
                "CUDA_VISIBLE_DEVICES",
                "LOCALAPPDATA",
                "PATH",
                "PATHEXT",
                "PROGRAMDATA",
                "SYSTEMROOT",
                "TEMP",
                "TMP",
                "TMPDIR",
                "USERPROFILE",
                "WINDIR",
            }
            or key.upper().startswith(("CUDA_", "NVIDIA_"))
        }
        child_environment.update(
            {
                "PYTHONDONTWRITEBYTECODE": "1",
                "KIRA_ORIGINAL_VOICE_PACKAGE_PATHS": self._environment.get("KIRA_ORIGINAL_VOICE_PACKAGE_PATHS", "[]"),
                "PYTHONNOUSERSITE": "1",
                "HF_HUB_OFFLINE": "1",
                "TRANSFORMERS_OFFLINE": "1",
                "HF_HUB_DISABLE_TELEMETRY": "1",
                "TOKENIZERS_PARALLELISM": "false",
                "NO_PROXY": "127.0.0.1,localhost",
            }
        )
        result = subprocess.run(
            [
                str(executable),
                "-B",
                str(self.worker_path),
                "--build-root",
                str(self.build_root),
                "--runtime-root",
                str(runtime_root),
                "--job",
                str(job_path),
                "--job-file-sha256",
                file_sha256(job_path),
                "--output-dir",
                str(output_dir),
                "--model-path",
                str(model_path),
                "--model-inventory",
                str(self.model_inventory_path),
                "--cache-root",
                str(cache_root),
            ],
            cwd=str(self.build_root),
            env=child_environment,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=300,
            check=False,
            shell=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "worker_failed_without_output").strip()
            raise OriginalVoiceError(f"original_voice_worker_failed: {detail[-2000:]}")

    def generate(
        self,
        text: str,
        *,
        profile_id: str,
        seed: int,
        delivery_preset: str = "neutral",
        character_id: str,
        attempt_id: str,
        output_dir: Path | None = None,
    ) -> dict[str, Any]:
        """Generate one private WAV+receipt pair through the isolated worker."""

        status = self.status()
        if not status["available"]:
            raise OriginalVoiceError("original_voice_runtime_not_ready")
        assert self.runtime_root is not None
        assert self.model_path is not None
        assert self.model_inventory_path is not None
        job = build_voice_job(
            text,
            runtime_root=self.runtime_root,
            profile_id=profile_id,
            seed=seed,
            delivery_preset=delivery_preset,
            character_id=character_id,
            attempt_id=attempt_id,
        )
        job_dir = self.jobs_root / f"voice-{job['job_sha256'][:20]}"
        try:
            job_dir.mkdir(parents=True, exist_ok=False)
        except FileExistsError as exc:
            raise OriginalVoiceError("original_voice_job_already_exists") from exc
        selected_output = (
            Path(output_dir).expanduser().resolve() if output_dir else job_dir / "output"
        )
        if selected_output.exists():
            raise OriginalVoiceError("original_voice_output_already_exists")
        request_path = job_dir / "request.json"
        _write_exclusive(request_path, canonical_json_bytes(job))
        cache_root = self.state_dir / "original_voice_cache"
        (self._runner or self._default_runner)(
            request_path,
            selected_output,
            self.runtime_root,
            self.model_path,
            cache_root,
        )
        persisted_job = validate_voice_job(
            _load_json_object(request_path, "persisted_voice_job_unreadable"),
            runtime_root=self.runtime_root,
        )
        if persisted_job["job_sha256"] != job["job_sha256"]:
            raise OriginalVoiceError("persisted_voice_job_changed_after_execution")
        result = validate_voice_output(selected_output, persisted_job)
        result.update(
            {
                "provider": self.PROVIDER,
                "job_path": str(request_path),
                "job_file_sha256": file_sha256(request_path),
            }
        )
        return result


__all__ = [
    "CATALOG_ID",
    "CONTINUITY_LABEL",
    "DELIVERY_PRESETS",
    "ENGINE_NAME",
    "EMOTION_CANDIDATE_LANE_PRESETS",
    "GENERATED_VOICE_REVIEW_SOURCES",
    "JOB_KIND",
    "OriginalVoiceError",
    "OriginalVoiceService",
    "OWNER_ACCEPTED_DELIVERY_PRESETS",
    "OWNER_REJECTED_DELIVERY_PRESETS",
    "RECEIPT_KIND",
    "MODEL_INVENTORY_SCHEMA",
    "build_synthesis_instruction",
    "build_voice_job",
    "canonical_json_bytes",
    "canonical_sha256",
    "compute_identity_binding_sha256",
    "delivery_preset_owner_review_status",
    "file_sha256",
    "file_artifact",
    "generated_voice_production_blockers",
    "load_profile_catalog",
    "load_model_inventory_reference",
    "normalize_delivery_preset",
    "validate_voice_job",
    "validate_voice_output",
]
