from pathlib import Path
import json,uuid
from datetime import datetime,timezone
class StudioError(RuntimeError):pass
def now():return datetime.now(timezone.utc).isoformat()
class VoiceStore:
    def __init__(self,state_dir):
        self.state_dir=Path(state_dir).resolve();self.state_dir.mkdir(parents=True,exist_ok=True)
        self.path=self.state_dir/'designs.json'
        self.data=json.loads(self.path.read_text(encoding='utf-8'))if self.path.exists()else{'project_id':'voice-designer','studio_voices':[],'assets':[]}
    def project(self,project_id):
        if project_id!='voice-designer':raise StudioError('Unknown voice workspace.')
        return self.data
    def _save(self,event):
        self.data['updated_at']=now();tmp=self.path.with_suffix('.tmp');tmp.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(self.path)
    def add_asset_for_project(self,project_id,payload):
        self.project(project_id);item={**payload,'asset_id':'audio-'+uuid.uuid4().hex[:12]};self.data['assets'].append(item);self._save('audio_saved');return item
