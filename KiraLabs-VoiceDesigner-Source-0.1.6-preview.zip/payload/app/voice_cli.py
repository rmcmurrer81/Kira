"""Ordinary command entry for the proven StudioVoiceService backend."""
from pathlib import Path
import argparse,json,os,sys
from kira_studio.store import VoiceStore
from kira_studio.studio_voice import StudioVoiceService

def main():
    sys.stdout.reconfigure(encoding="utf-8");sys.stderr.reconfigure(encoding="utf-8")
    p=argparse.ArgumentParser();p.add_argument('--request',type=Path,required=True);args=p.parse_args()
    root=Path(__file__).resolve().parent;install=root.parent;data=install/'data';request=json.loads(args.request.read_text(encoding='utf-8-sig'))
    name=str(request.get('name','My original voice')).strip();description=str(request['description']).strip();text=str(request['text']).strip();seed=int(request.get('seed',1161001))
    if not 0<=seed<=2**63-1:raise ValueError('Seed must be a nonnegative integer below 2^63.')
    store=VoiceStore(data/'voices');service=StudioVoiceService(store,root,environment={**os.environ,'KIRA_ORIGINAL_VOICE_PYTHON':str(install/'runtime/python.exe'),'KIRA_ORIGINAL_VOICE_MODEL_PATH':str(data/'models/Qwen3-TTS-12Hz-1.7B-VoiceDesign')})
    existing=next((v for v in store.data['studio_voices']if v['name']==name and v['description']==description and v['seed']==seed),None)
    voice=existing or service.create('voice-designer',{'name':name,'description':description})
    if existing is None:store.data['studio_voices'][-1]['seed']=seed;voice['seed']=seed;store._save('seed_selected')
    result=service.audition('voice-designer',voice['voice_id'],{'text':text,'delivery_preset':'neutral'})
    asset=result['asset'];export={'name':name,'description':description,'text':text,'seed':seed,'engine':'Qwen3-TTS-12Hz-1.7B-VoiceDesign','continuity':'best effort; not an identical-speaker guarantee','synthetic':True,'reference_audio_used':False,'voice_cloning_used':False}
    print(json.dumps({'wav':asset['local_path'],'duration':asset.get('duration_seconds'),'design':export},ensure_ascii=False),flush=True)
    return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:print(str(exc),file=sys.stderr);raise SystemExit(1)
