Kira Labs Voice Designer 0.1.6-preview
NATIVE DESKTOP APP — BUILT CANDIDATE, NOT RELEASE-QUALIFIED

The native WPF application replaces the previous PowerShell-hosted GUI. Its
normal entry is app/KiraLabs.VoiceDesigner.exe. The isolated Python engine,
fixed model revision, dependency versions and automatic setup are unchanged
from the tested 0.1.5 provisioning composition. No donor/reference upload,
generic/system voice fallback, support-capture code or test harness is shipped.

This candidate has not been installed, launched or used for generation by the
packaging author. Native GUI button interaction is UNVERIFIED. The previous
0.1.5 existing-host CLI/install/uninstall/reinstall results remain useful
background evidence, but do not qualify this new GUI or installer. Keep the
tested 0.1.5 release pack separate until this candidate is reviewed and tested.

Setup downloads its own Python, required packages and the 4.52 GB model.
Generation is local/offline afterward. CUDA is required; CPU generation is not
implemented. Reference hardware is Windows 11, 32 GB RAM class and an RTX 5060
Ti 16 GB. A lower minimum has not been established. Hardware/driver/space/path
warnings allow continuing; they are not performance guarantees.

Default installation: %LOCALAPPDATA%/KiraLabs/VoiceDesigner. A short custom
folder ending in VoiceDesigner or VoiceDesigner-Test is supported. A root
under 80 characters is recommended because package and temporary paths grow
below it; this is not a guarantee that every package filename will fit on
every Windows profile. Setup does not change Windows long-path policy,
security settings, driver configuration or automatic reboot settings.

Windows shortcuts target the native EXE. Uninstall.cmd remains available in
the owned installation folder; the uninstaller removes only owned app/runtime
and preserves data/voices, models, logs and caches. Native shortcuts and legacy
0.1.5 shortcuts are removed only when their targets belong to the owned root.
Older files already in an upgraded app folder are not silently purged.

Build.ps1 compiles the bootstrapper and produces the installer/source ZIP.
It never runs an installer or voice engine, and refuses to overwrite existing
build products. Use a fresh candidate folder for a changed build. The reviewed
GUI EXE is already in payload/app. Its C# source is in gui-source; BuildGUI.ps1
can compile it in a fresh source copy after removing/replacing no preserved
review artifact. Third-party and application licenses are included.

No app-access denial has been bypassed. A native GUI launch was rejected by
app-access review; interactive validation must remain unverified until an
allowed genuine test can be performed.
