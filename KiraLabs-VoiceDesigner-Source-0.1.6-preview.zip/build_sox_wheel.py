"""Deterministically package unchanged official sox1.5.0 Python files as a wheel.
No setup.py execution, archive filesystem extraction, import, ACL or filter changes.
"""
from pathlib import Path,PurePosixPath
import base64,csv,hashlib,io,json,tarfile,zipfile
BASE=Path(__file__).resolve().parent
SOURCE=BASE/'downloads/sox-1.5.0.tar.gz'
EXPECTED='12c7be5bb1f548d891fe11e82c08cf5f1a1d74e225298f60082e5aeb2469ada0'
raw=SOURCE.read_bytes();assert len(raw)==63905 and hashlib.sha256(raw).hexdigest()==EXPECTED
payload={};original=[];dist='sox-1.5.0.dist-info'
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as archive:
 for member in archive.getmembers():
  path=PurePosixPath(member.name)
  assert not path.is_absolute()and'..'not in path.parts and'\\'not in member.name
  if not member.isfile():continue
  relative='/'.join(path.parts[1:])
  if relative.startswith('sox/'):
   assert member.size<1048576
   data=archive.extractfile(member).read();assert len(data)==member.size
   payload[relative]=data;original.append({'file':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 for rel,target in [('PKG-INFO',dist+'/METADATA'),('LICENSE',dist+'/LICENSE'),('sox.egg-info/top_level.txt',dist+'/top_level.txt')]:
  member=archive.getmember('sox-1.5.0/'+rel);data=archive.extractfile(member).read();assert len(data)==member.size;payload[target]=data
assert len(original)==7 and b'Name: sox' in payload[dist+'/METADATA']and b'Version: 1.5.0' in payload[dist+'/METADATA']
payload[dist+'/WHEEL']=b'Wheel-Version: 1.0\nGenerator: KiraLabs verified-source deterministic packager\nRoot-Is-Purelib: true\nBuild: 1kiralabs\nTag: py3-none-any\n'
payload[dist+'/KIRALABS-BUILD-NOTICE.txt']=b'Locally repackaged wheel from official PyPI sox1.5.0 sdist SHA256 12c7be5bb1f548d891fe11e82c08cf5f1a1d74e225298f60082e5aeb2469ada0. All seven package files, upstream metadata and BSD license are unchanged. No setup.py execution or tar filesystem extraction. This is not an official upstream binary wheel.\n'
record=io.StringIO(newline='');writer=csv.writer(record,lineterminator='\n')
for name,data in sorted(payload.items()):writer.writerow([name,'sha256='+base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b'=').decode(),len(data)])
writer.writerow([dist+'/RECORD','','']);payload[dist+'/RECORD']=record.getvalue().encode()
output=BASE/'sox-1.5.0-1kiralabs-py3-none-any.whl'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as wheel:
 for name,data in sorted(payload.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.create_system=3;info.external_attr=0o100644<<16;wheel.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
result={'source_url':'https://files.pythonhosted.org/packages/3d/a2/d8e0d8fd7abf509ead4a2cb0fb24e5758b5330166bf9223d5cb9f98a7e8d/sox-1.5.0.tar.gz','source_bytes':63905,'source_sha256':EXPECTED,'wheel':output.name,'wheel_bytes':output.stat().st_size,'wheel_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'official_upstream_wheel':False,'package_files':original,'package_code_changed':False,'setup_executed':False,'filesystem_archive_extraction':False,'license':'BSD-3-Clause','wheel_record_complete':True}
(BASE/'sox-wheel-provenance.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(BASE/'payload/app/licenses/SoX-Python-LICENSE.txt').write_bytes(payload[dist+'/LICENSE'])
print(json.dumps(result))
