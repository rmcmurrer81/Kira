using System;
using System.IO;
using System.IO.Compression;
using System.Diagnostics;
using System.Reflection;
using System.Linq;
using System.Text;
class Setup {
 static StreamWriter log; static readonly object sync=new object();
 static void Write(string text,bool error=false){lock(sync){if(log!=null){log.WriteLine(text);log.Flush();}if(error)Console.Error.WriteLine(text);else Console.WriteLine(text);}}
 static string Quote(string value){var result=new StringBuilder("\"");int slashes=0;foreach(char c in value){if(c=='\\'){slashes++;continue;}if(c=='"'){result.Append('\\',slashes*2+1);result.Append('"');slashes=0;continue;}result.Append('\\',slashes);result.Append(c);slashes=0;}result.Append('\\',slashes*2);result.Append('"');return result.ToString();}
 static string ChosenInstall(string[] args){for(int i=0;i<args.Length;i++){if(args[i].Equals("-InstallDir",StringComparison.OrdinalIgnoreCase)&&i+1<args.Length)return Path.GetFullPath(args[i+1]);if(args[i].StartsWith("-InstallDir:",StringComparison.OrdinalIgnoreCase))return Path.GetFullPath(args[i].Substring(args[i].IndexOf(':')+1));}return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"KiraLabs","VoiceDesigner");}
 static int Main(string[] args){
  string stage=null;bool completed=false;
  try{
   string install=ChosenInstall(args);string parent=Path.GetDirectoryName(install.TrimEnd(Path.DirectorySeparatorChar));Directory.CreateDirectory(parent);
   string logPath=Path.Combine(parent,"KiraLabs-VoiceDesigner-Setup-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+".log");log=new StreamWriter(logPath,true,Encoding.UTF8);
   Write("Kira Labs Voice Designer Setup 0.1.6-preview");Write("Setup log: "+logPath);Write("Chosen installation: "+install);
   stage=Path.Combine(parent,".KiraLabsVoiceDesignerSetup-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(stage);
   string zip=Path.Combine(stage,"setup.zip");using(Stream input=Assembly.GetExecutingAssembly().GetManifestResourceStream("setup.zip"))using(FileStream output=File.Create(zip)){input.CopyTo(output);}ZipFile.ExtractToDirectory(zip,stage);
   string ps=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"WindowsPowerShell\\v1.0\\powershell.exe");string command="-NoProfile -ExecutionPolicy Bypass -File "+Quote(Path.Combine(stage,"Install-VoiceDesigner.ps1"));if(args.Length>0)command+=" "+String.Join(" ",args.Select(Quote));
   Write("Starting ordinary PowerShell installer. Errors and progress are copied below.");
   var info=new ProcessStartInfo(ps,command);info.UseShellExecute=false;info.WorkingDirectory=stage;info.EnvironmentVariables["PSModulePath"]=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"WindowsPowerShell\\v1.0\\Modules");info.RedirectStandardOutput=true;info.RedirectStandardError=true;
   using(Process process=new Process()){process.StartInfo=info;process.OutputDataReceived+=(sender,e)=>{if(e.Data!=null)Write(e.Data);};process.ErrorDataReceived+=(sender,e)=>{if(e.Data!=null)Write(e.Data,true);};process.Start();process.BeginOutputReadLine();process.BeginErrorReadLine();process.WaitForExit();completed=process.ExitCode==0||process.ExitCode==3010;Write("Installer exit code: "+process.ExitCode);return process.ExitCode;}
  }catch(Exception e){Write("Setup failed: "+e.ToString(),true);if(stage!=null)Write("Installer files retained at "+stage,true);return 1;}
  finally{try{if(completed&&stage!=null&&Path.GetFileName(stage).StartsWith(".KiraLabsVoiceDesignerSetup-",StringComparison.Ordinal))Directory.Delete(stage,true);}catch(Exception e){Write("Temporary extraction cleanup: "+e.Message,true);}lock(sync){if(log!=null){log.Dispose();log=null;}}}
 }
}
