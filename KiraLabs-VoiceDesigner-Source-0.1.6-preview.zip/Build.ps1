$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$version=(Get-Content -LiteralPath (Join-Path $root 'provision-manifest.json') -Raw|ConvertFrom-Json).version
$output=Join-Path $root ('KiraLabs-VoiceDesigner-Setup-'+$version+'.exe')
$sourceZip=Join-Path $root ('KiraLabs-VoiceDesigner-Source-'+$version+'.zip')
$payload=Join-Path $root 'payload'
$payloadZip=Join-Path $root 'payload.zip'
$bundle=Join-Path $root 'setup-bundle.zip'
foreach($product in @($output,$sourceZip,$payloadZip,$bundle)){if(Test-Path -LiteralPath $product){throw ('Preserve existing build product: '+$product+'. Use a fresh candidate folder.')}}
Add-Type -AssemblyName System.IO.Compression,System.IO.Compression.FileSystem
$archive=[IO.Compression.ZipFile]::Open($payloadZip,[IO.Compression.ZipArchiveMode]::Create)
try{
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $payload 'app') -Recurse -File){
  if($file.FullName-match'[\\/]__pycache__[\\/]' -or $file.Extension-eq'.pyc' -or $file.Name-eq'VoiceDesigner.ps1'){throw 'Unwanted generated/legacy GUI file in payload.'}
  $entry=$file.FullName.Substring($payload.Length+1).Replace('\','/')
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
 }
}finally{$archive.Dispose()}
$items=@('Setup.cmd','Install-VoiceDesigner.ps1','payload.zip','provision-manifest.json','requirements-runtime.txt','get-pip.py','sox-1.5.0-1kiralabs-py3-none-any.whl')|ForEach-Object{Join-Path $root $_}
Compress-Archive -LiteralPath $items -DestinationPath $bundle
$compiler=Join-Path $env:SystemRoot 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
& $compiler /nologo /target:exe /optimize+ ('/out:'+$output) ('/resource:'+$bundle+',setup.zip') /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll (Join-Path $root 'Setup.cs')
if($LASTEXITCODE-ne0){throw 'Installer compilation failed; preserved products are incomplete.'}
$archive=[IO.Compression.ZipFile]::Open($sourceZip,[IO.Compression.ZipArchiveMode]::Create)
try{
 foreach($name in @('Build.ps1','Setup.cs','Setup.cmd','Install-VoiceDesigner.ps1','provision-manifest.json','requirements-runtime.txt','get-pip.py','sox-1.5.0-1kiralabs-py3-none-any.whl','sox-wheel-provenance.json','build_sox_wheel.py','LICENSE-APPLICATION.txt','README-CANDIDATE.txt','native-gui-installer.review.patch')){
  $file=Join-Path $root $name
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file,$name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
 }
 foreach($folder in @('payload','gui-source','shared-fixes')){
  foreach($file in Get-ChildItem -LiteralPath (Join-Path $root $folder) -Recurse -File){
   if($file.FullName-match'[\\/]__pycache__[\\/]' -or $file.Extension-eq'.pyc' -or $file.Name-eq'VoiceDesigner.ps1'){throw 'Unwanted generated/legacy GUI source entry.'}
   $entry=$file.FullName.Substring($root.Length+1).Replace('\','/')
   [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
  }
 }
}finally{$archive.Dispose()}
Get-FileHash -LiteralPath $output,$sourceZip,$payloadZip,$bundle -Algorithm SHA256
